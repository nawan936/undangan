/*!

pica
https://github.com/nodeca/pica

*/
!(function (t) {
  if ("object" == typeof exports && "undefined" != typeof module)
    module.exports = t();
  else if ("function" == typeof define && define.amd) define([], t);
  else {
    ("undefined" != typeof window
      ? window
      : "undefined" != typeof global
      ? global
      : "undefined" != typeof self
      ? self
      : this
    ).pica = t();
  }
})(function () {
  return (function t(e, i, r) {
    function n(a, A) {
      if (!i[a]) {
        if (!e[a]) {
          var s = "function" == typeof require && require;
          if (!A && s) return s(a, !0);
          if (o) return o(a, !0);
          var u = new Error("Cannot find module '" + a + "'");
          throw ((u.code = "MODULE_NOT_FOUND"), u);
        }
        var h = (i[a] = { exports: {} });
        e[a][0].call(
          h.exports,
          function (t) {
            return n(e[a][1][t] || t);
          },
          h,
          h.exports,
          t,
          e,
          i,
          r
        );
      }
      return i[a].exports;
    }
    for (
      var o = "function" == typeof require && require, a = 0;
      a < r.length;
      a++
    )
      n(r[a]);
    return n;
  })(
    {
      1: [
        function (t, e, i) {
          "use strict";
          var r = t("inherits"),
            n = t("multimath"),
            o = t("multimath/lib/unsharp_mask"),
            a = t("./mm_resize");
          function A(t) {
            var e = t || [],
              i = { js: e.indexOf("js") >= 0, wasm: e.indexOf("wasm") >= 0 };
            n.call(this, i),
              (this.features = { js: i.js, wasm: i.wasm && this.has_wasm() }),
              this.use(o),
              this.use(a);
          }
          r(A, n),
            (A.prototype.resizeAndUnsharp = function (t, e) {
              var i = this.resize(t, e);
              return (
                t.unsharpAmount &&
                  this.unsharp_mask(
                    i,
                    t.toWidth,
                    t.toHeight,
                    t.unsharpAmount,
                    t.unsharpRadius,
                    t.unsharpThreshold
                  ),
                i
              );
            }),
            (e.exports = A);
        },
        {
          "./mm_resize": 4,
          inherits: 15,
          multimath: 16,
          "multimath/lib/unsharp_mask": 19,
        },
      ],
      2: [
        function (t, e, i) {
          "use strict";
          function r(t) {
            return t < 0 ? 0 : t > 255 ? 255 : t;
          }
          e.exports = {
            convolveHorizontally: function (t, e, i, n, o, a) {
              var A,
                s,
                u,
                h,
                f,
                c,
                l,
                g,
                I,
                d,
                m,
                p = 0,
                w = 0;
              for (I = 0; I < n; I++) {
                for (f = 0, d = 0; d < o; d++) {
                  for (
                    c = a[f++],
                      l = a[f++],
                      g = (p + 4 * c) | 0,
                      A = s = u = h = 0;
                    l > 0;
                    l--
                  )
                    (h = (h + (m = a[f++]) * t[g + 3]) | 0),
                      (u = (u + m * t[g + 2]) | 0),
                      (s = (s + m * t[g + 1]) | 0),
                      (A = (A + m * t[g]) | 0),
                      (g = (g + 4) | 0);
                  (e[w + 3] = r((h + 8192) >> 14)),
                    (e[w + 2] = r((u + 8192) >> 14)),
                    (e[w + 1] = r((s + 8192) >> 14)),
                    (e[w] = r((A + 8192) >> 14)),
                    (w = (w + 4 * n) | 0);
                }
                (w = (4 * (I + 1)) | 0), (p = ((I + 1) * i * 4) | 0);
              }
            },
            convolveVertically: function (t, e, i, n, o, a) {
              var A,
                s,
                u,
                h,
                f,
                c,
                l,
                g,
                I,
                d,
                m,
                p = 0,
                w = 0;
              for (I = 0; I < n; I++) {
                for (f = 0, d = 0; d < o; d++) {
                  for (
                    c = a[f++],
                      l = a[f++],
                      g = (p + 4 * c) | 0,
                      A = s = u = h = 0;
                    l > 0;
                    l--
                  )
                    (h = (h + (m = a[f++]) * t[g + 3]) | 0),
                      (u = (u + m * t[g + 2]) | 0),
                      (s = (s + m * t[g + 1]) | 0),
                      (A = (A + m * t[g]) | 0),
                      (g = (g + 4) | 0);
                  (e[w + 3] = r((h + 8192) >> 14)),
                    (e[w + 2] = r((u + 8192) >> 14)),
                    (e[w + 1] = r((s + 8192) >> 14)),
                    (e[w] = r((A + 8192) >> 14)),
                    (w = (w + 4 * n) | 0);
                }
                (w = (4 * (I + 1)) | 0), (p = ((I + 1) * i * 4) | 0);
              }
            },
          };
        },
        {},
      ],
      3: [
        function (t, e, i) {
          "use strict";
          e.exports =
            "AGFzbQEAAAABFAJgBn9/f39/fwBgB39/f39/f38AAg8BA2VudgZtZW1vcnkCAAEDAwIAAQQEAXAAAAcZAghjb252b2x2ZQAACmNvbnZvbHZlSFYAAQkBAArmAwLBAwEQfwJAIANFDQAgBEUNACAFQQRqIRVBACEMQQAhDQNAIA0hDkEAIRFBACEHA0AgB0ECaiESAn8gBSAHQQF0IgdqIgZBAmouAQAiEwRAQQAhCEEAIBNrIRQgFSAHaiEPIAAgDCAGLgEAakECdGohEEEAIQlBACEKQQAhCwNAIBAoAgAiB0EYdiAPLgEAIgZsIAtqIQsgB0H/AXEgBmwgCGohCCAHQRB2Qf8BcSAGbCAKaiEKIAdBCHZB/wFxIAZsIAlqIQkgD0ECaiEPIBBBBGohECAUQQFqIhQNAAsgEiATagwBC0EAIQtBACEKQQAhCUEAIQggEgshByABIA5BAnRqIApBgMAAakEOdSIGQf8BIAZB/wFIG0EQdEGAgPwHcUEAIAZBAEobIAtBgMAAakEOdSIGQf8BIAZB/wFIG0EYdEEAIAZBAEobciAJQYDAAGpBDnUiBkH/ASAGQf8BSBtBCHRBgP4DcUEAIAZBAEobciAIQYDAAGpBDnUiBkH/ASAGQf8BSBtB/wFxQQAgBkEAShtyNgIAIA4gA2ohDiARQQFqIhEgBEcNAAsgDCACaiEMIA1BAWoiDSADRw0ACwsLIQACQEEAIAIgAyAEIAUgABAAIAJBACAEIAUgBiABEAALCw==";
        },
        {},
      ],
      4: [
        function (t, e, i) {
          "use strict";
          e.exports = {
            name: "resize",
            fn: t("./resize"),
            wasm_fn: t("./resize_wasm"),
            wasm_src: t("./convolve_wasm_base64"),
          };
        },
        { "./convolve_wasm_base64": 3, "./resize": 5, "./resize_wasm": 8 },
      ],
      5: [
        function (t, e, i) {
          "use strict";
          var r = t("./resize_filter_gen"),
            n = t("./convolve").convolveHorizontally,
            o = t("./convolve").convolveVertically;
          e.exports = function (t) {
            var e = t.src,
              i = t.width,
              a = t.height,
              A = t.toWidth,
              s = t.toHeight,
              u = t.scaleX || t.toWidth / t.width,
              h = t.scaleY || t.toHeight / t.height,
              f = t.offsetX || 0,
              c = t.offsetY || 0,
              l = t.dest || new Uint8Array(A * s * 4),
              g = void 0 === t.quality ? 3 : t.quality,
              I = t.alpha || !1,
              d = r(g, i, A, u, f),
              m = r(g, a, s, h, c),
              p = new Uint8Array(A * a * 4);
            return (
              n(e, p, i, a, A, d),
              o(p, l, a, A, s, m),
              I ||
                (function (t, e, i) {
                  for (var r = 3, n = (e * i * 4) | 0; r < n; )
                    (t[r] = 255), (r = (r + 4) | 0);
                })(l, A, s),
              l
            );
          };
        },
        { "./convolve": 2, "./resize_filter_gen": 6 },
      ],
      6: [
        function (t, e, i) {
          "use strict";
          var r = t("./resize_filter_info");
          function n(t) {
            return Math.round(16383 * t);
          }
          e.exports = function (t, e, i, o, a) {
            var A,
              s,
              u,
              h,
              f,
              c,
              l,
              g,
              I,
              d,
              m,
              p,
              w,
              B,
              b,
              y,
              _,
              E = r[t].filter,
              C = 1 / o,
              v = Math.min(1, o),
              Q = r[t].win / v,
              x = Math.floor(2 * (Q + 1)),
              M = new Int16Array((x + 2) * i),
              D = 0,
              U = !M.subarray || !M.set;
            for (A = 0; A < i; A++) {
              for (
                s = (A + 0.5) * C + a,
                  u = Math.max(0, Math.floor(s - Q)),
                  f = (h = Math.min(e - 1, Math.ceil(s + Q))) - u + 1,
                  c = new Float32Array(f),
                  l = new Int16Array(f),
                  g = 0,
                  I = u,
                  d = 0;
                I <= h;
                I++, d++
              )
                (g += m = E((I + 0.5 - s) * v)), (c[d] = m);
              for (p = 0, d = 0; d < c.length; d++)
                (p += w = c[d] / g), (l[d] = n(w));
              for (l[i >> 1] += n(1 - p), B = 0; B < l.length && 0 === l[B]; )
                B++;
              if (B < l.length) {
                for (b = l.length - 1; b > 0 && 0 === l[b]; ) b--;
                if (
                  ((y = u + B), (_ = b - B + 1), (M[D++] = y), (M[D++] = _), U)
                )
                  for (d = B; d <= b; d++) M[D++] = l[d];
                else M.set(l.subarray(B, b + 1), D), (D += _);
              } else (M[D++] = 0), (M[D++] = 0);
            }
            return M;
          };
        },
        { "./resize_filter_info": 7 },
      ],
      7: [
        function (t, e, i) {
          "use strict";
          e.exports = [
            {
              win: 0.5,
              filter: function (t) {
                return t >= -0.5 && t < 0.5 ? 1 : 0;
              },
            },
            {
              win: 1,
              filter: function (t) {
                if (t <= -1 || t >= 1) return 0;
                if (t > -1.1920929e-7 && t < 1.1920929e-7) return 1;
                var e = t * Math.PI;
                return (Math.sin(e) / e) * (0.54 + 0.46 * Math.cos(e / 1));
              },
            },
            {
              win: 2,
              filter: function (t) {
                if (t <= -2 || t >= 2) return 0;
                if (t > -1.1920929e-7 && t < 1.1920929e-7) return 1;
                var e = t * Math.PI;
                return ((Math.sin(e) / e) * Math.sin(e / 2)) / (e / 2);
              },
            },
            {
              win: 3,
              filter: function (t) {
                if (t <= -3 || t >= 3) return 0;
                if (t > -1.1920929e-7 && t < 1.1920929e-7) return 1;
                var e = t * Math.PI;
                return ((Math.sin(e) / e) * Math.sin(e / 3)) / (e / 3);
              },
            },
          ];
        },
        {},
      ],
      8: [
        function (t, e, i) {
          "use strict";
          var r = t("./resize_filter_gen");
          var n = !0;
          try {
            n = 1 === new Uint32Array(new Uint8Array([1, 0, 0, 0]).buffer)[0];
          } catch (t) {}
          function o(t, e, i) {
            if (n)
              e.set(
                (function (t) {
                  return new Uint8Array(t.buffer, 0, t.byteLength);
                })(t),
                i
              );
            else
              for (var r = i, o = 0; o < t.length; o++) {
                var a = t[o];
                (e[r++] = 255 & a), (e[r++] = (a >> 8) & 255);
              }
          }
          e.exports = function (t) {
            var e = t.src,
              i = t.width,
              n = t.height,
              a = t.toWidth,
              A = t.toHeight,
              s = t.scaleX || t.toWidth / t.width,
              u = t.scaleY || t.toHeight / t.height,
              h = t.offsetX || 0,
              f = t.offsetY || 0,
              c = t.dest || new Uint8Array(a * A * 4),
              l = void 0 === t.quality ? 3 : t.quality,
              g = t.alpha || !1,
              I = r(l, i, a, s, h),
              d = r(l, n, A, u, f),
              m = this.__align(0 + Math.max(e.byteLength, c.byteLength)),
              p = this.__align(m + n * a * 4),
              w = this.__align(p + I.byteLength),
              B = w + d.byteLength,
              b = this.__instance("resize", B),
              y = new Uint8Array(this.__memory.buffer),
              _ = new Uint32Array(this.__memory.buffer),
              E = new Uint32Array(e.buffer);
            return (
              _.set(E),
              o(I, y, p),
              o(d, y, w),
              (b.exports.convolveHV || b.exports._convolveHV)(
                p,
                w,
                m,
                i,
                n,
                a,
                A
              ),
              new Uint32Array(c.buffer).set(
                new Uint32Array(this.__memory.buffer, 0, A * a)
              ),
              g ||
                (function (t, e, i) {
                  for (var r = 3, n = (e * i * 4) | 0; r < n; )
                    (t[r] = 255), (r = (r + 4) | 0);
                })(c, a, A),
              c
            );
          };
        },
        { "./resize_filter_gen": 6 },
      ],
      9: [
        function (t, e, i) {
          "use strict";
          function r(t, e) {
            (this.create = t),
              (this.available = []),
              (this.acquired = {}),
              (this.lastId = 1),
              (this.timeoutId = 0),
              (this.idle = e || 2e3);
          }
          (r.prototype.acquire = function () {
            var t,
              e = this;
            return (
              0 !== this.available.length
                ? (t = this.available.pop())
                : (((t = this.create()).id = this.lastId++),
                  (t.release = function () {
                    return e.release(t);
                  })),
              (this.acquired[t.id] = t),
              t
            );
          }),
            (r.prototype.release = function (t) {
              var e = this;
              delete this.acquired[t.id],
                (t.lastUsed = Date.now()),
                this.available.push(t),
                0 === this.timeoutId &&
                  (this.timeoutId = setTimeout(function () {
                    return e.gc();
                  }, 100));
            }),
            (r.prototype.gc = function () {
              var t = this,
                e = Date.now();
              (this.available = this.available.filter(function (i) {
                return !(e - i.lastUsed > t.idle) || (i.destroy(), !1);
              })),
                0 !== this.available.length
                  ? (this.timeoutId = setTimeout(function () {
                      return t.gc();
                    }, 100))
                  : (this.timeoutId = 0);
            }),
            (e.exports = r);
        },
        {},
      ],
      10: [
        function (t, e, i) {
          "use strict";
          e.exports = function (t, e, i, r, n, o) {
            var a = i / t,
              A = r / e,
              s = (2 * o + 2 + 1) / n;
            if (s > 0.5) return [[i, r]];
            var u = Math.ceil(Math.log(Math.min(a, A)) / Math.log(s));
            if (u <= 1) return [[i, r]];
            for (var h = [], f = 0; f < u; f++) {
              var c = Math.round(
                  Math.pow(Math.pow(t, u - f - 1) * Math.pow(i, f + 1), 1 / u)
                ),
                l = Math.round(
                  Math.pow(Math.pow(e, u - f - 1) * Math.pow(r, f + 1), 1 / u)
                );
              h.push([c, l]);
            }
            return h;
          };
        },
        {},
      ],
      11: [
        function (t, e, i) {
          "use strict";
          function r(t) {
            var e = Math.round(t);
            return Math.abs(t - e) < 1e-5 ? e : Math.floor(t);
          }
          function n(t) {
            var e = Math.round(t);
            return Math.abs(t - e) < 1e-5 ? e : Math.ceil(t);
          }
          e.exports = function (t) {
            var e,
              i,
              o,
              a,
              A,
              s,
              u = t.toWidth / t.width,
              h = t.toHeight / t.height,
              f = r(t.srcTileSize * u) - 2 * t.destTileBorder,
              c = r(t.srcTileSize * h) - 2 * t.destTileBorder;
            if (f < 1 || c < 1)
              throw new Error(
                "Internal error in pica: target tile width/height is too small."
              );
            var l,
              g = [];
            for (a = 0; a < t.toHeight; a += c)
              for (o = 0; o < t.toWidth; o += f)
                (e = o - t.destTileBorder) < 0 && (e = 0),
                  e + (A = o + f + t.destTileBorder - e) >= t.toWidth &&
                    (A = t.toWidth - e),
                  (i = a - t.destTileBorder) < 0 && (i = 0),
                  i + (s = a + c + t.destTileBorder - i) >= t.toHeight &&
                    (s = t.toHeight - i),
                  (l = {
                    toX: e,
                    toY: i,
                    toWidth: A,
                    toHeight: s,
                    toInnerX: o,
                    toInnerY: a,
                    toInnerWidth: f,
                    toInnerHeight: c,
                    offsetX: e / u - r(e / u),
                    offsetY: i / h - r(i / h),
                    scaleX: u,
                    scaleY: h,
                    x: r(e / u),
                    y: r(i / h),
                    width: n(A / u),
                    height: n(s / h),
                  }),
                  g.push(l);
            return g;
          };
        },
        {},
      ],
      12: [
        function (t, e, i) {
          "use strict";
          function r(t) {
            return Object.prototype.toString.call(t);
          }
          (e.exports.isCanvas = function (t) {
            var e = r(t);
            return (
              "[object HTMLCanvasElement]" === e ||
              "[object OffscreenCanvas]" === e ||
              "[object Canvas]" === e
            );
          }),
            (e.exports.isImage = function (t) {
              return "[object HTMLImageElement]" === r(t);
            }),
            (e.exports.isImageBitmap = function (t) {
              return "[object ImageBitmap]" === r(t);
            }),
            (e.exports.limiter = function (t) {
              var e = 0,
                i = [];
              function r() {
                e < t && i.length && (e++, i.shift()());
              }
              return function (t) {
                return new Promise(function (n, o) {
                  i.push(function () {
                    t().then(
                      function (t) {
                        n(t), e--, r();
                      },
                      function (t) {
                        o(t), e--, r();
                      }
                    );
                  }),
                    r();
                });
              };
            }),
            (e.exports.cib_quality_name = function (t) {
              switch (t) {
                case 0:
                  return "pixelated";
                case 1:
                  return "low";
                case 2:
                  return "medium";
              }
              return "high";
            }),
            (e.exports.cib_support = function (t) {
              return Promise.resolve()
                .then(function () {
                  if ("undefined" == typeof createImageBitmap) return !1;
                  var e = t(100, 100);
                  return createImageBitmap(e, 0, 0, 100, 100, {
                    resizeWidth: 10,
                    resizeHeight: 10,
                    resizeQuality: "high",
                  }).then(function (t) {
                    var i = 10 === t.width;
                    return t.close(), (e = null), i;
                  });
                })
                .catch(function () {
                  return !1;
                });
            });
        },
        {},
      ],
      13: [
        function (t, e, i) {
          "use strict";
          e.exports = function () {
            var e,
              i = t("./mathlib");
            onmessage = function (t) {
              var r = t.data.opts;
              e || (e = new i(t.data.features));
              var n = e.resizeAndUnsharp(r);
              postMessage({ result: n }, [n.buffer]);
            };
          };
        },
        { "./mathlib": 1 },
      ],
      14: [
        function (t, e, i) {
          var r, n, o, a, A, s;
          function u(t, e, i, r, n, o) {
            var a, A, s, u, h, f, c, l, g, I, d, m, p, w;
            for (g = 0; g < o; g++) {
              for (
                c = g,
                  l = 0,
                  u = h = (a = t[(f = g * n)]) * r[6],
                  d = r[0],
                  m = r[1],
                  p = r[4],
                  w = r[5],
                  I = 0;
                I < n;
                I++
              )
                (s = (A = t[f]) * d + a * m + u * p + h * w),
                  (h = u),
                  (u = s),
                  (a = A),
                  (i[l] = u),
                  l++,
                  f++;
              for (
                l--,
                  c += o * (n - 1),
                  u = h = (a = t[--f]) * r[7],
                  A = a,
                  d = r[2],
                  m = r[3],
                  I = n - 1;
                I >= 0;
                I--
              )
                (s = A * d + a * m + u * p + h * w),
                  (h = u),
                  (u = s),
                  (a = A),
                  (A = t[f]),
                  (e[c] = i[l] + u),
                  f--,
                  l--,
                  (c -= o);
            }
          }
          e.exports = function (t, e, i, h) {
            if (h) {
              var f = new Uint16Array(t.length),
                c = new Float32Array(Math.max(e, i)),
                l = (function (t) {
                  t < 0.5 && (t = 0.5);
                  var e = Math.exp(0.527076) / t,
                    i = Math.exp(-e),
                    u = Math.exp(-2 * e),
                    h = ((1 - i) * (1 - i)) / (1 + 2 * e * i - u);
                  return (
                    (r = h),
                    (n = h * (e - 1) * i),
                    (o = h * (e + 1) * i),
                    (a = -h * u),
                    (A = 2 * i),
                    (s = -u),
                    new Float32Array([
                      r,
                      n,
                      o,
                      a,
                      A,
                      s,
                      (r + n) / (1 - A - s),
                      (o + a) / (1 - A - s),
                    ])
                  );
                })(h);
              u(t, f, c, l, e, i), u(f, t, c, l, i, e);
            }
          };
        },
        {},
      ],
      15: [
        function (t, e, i) {
          "function" == typeof Object.create
            ? (e.exports = function (t, e) {
                e &&
                  ((t.super_ = e),
                  (t.prototype = Object.create(e.prototype, {
                    constructor: {
                      value: t,
                      enumerable: !1,
                      writable: !0,
                      configurable: !0,
                    },
                  })));
              })
            : (e.exports = function (t, e) {
                if (e) {
                  t.super_ = e;
                  var i = function () {};
                  (i.prototype = e.prototype),
                    (t.prototype = new i()),
                    (t.prototype.constructor = t);
                }
              });
        },
        {},
      ],
      16: [
        function (t, e, i) {
          "use strict";
          var r = t("object-assign"),
            n = t("./lib/base64decode"),
            o = t("./lib/wa_detect"),
            a = { js: !0, wasm: !0 };
          function A(t) {
            if (!(this instanceof A)) return new A(t);
            var e = r({}, a, t || {});
            if (
              ((this.options = e),
              (this.__cache = {}),
              (this.__init_promise = null),
              (this.__modules = e.modules || {}),
              (this.__memory = null),
              (this.__wasm = {}),
              (this.__isLE =
                1 === new Uint32Array(new Uint8Array([1, 0, 0, 0]).buffer)[0]),
              !this.options.js && !this.options.wasm)
            )
              throw new Error(
                'mathlib: at least "js" or "wasm" should be enabled'
              );
          }
          (A.prototype.has_wasm = o),
            (A.prototype.use = function (t) {
              return (
                (this.__modules[t.name] = t),
                this.options.wasm && this.has_wasm() && t.wasm_fn
                  ? (this[t.name] = t.wasm_fn)
                  : (this[t.name] = t.fn),
                this
              );
            }),
            (A.prototype.init = function () {
              if (this.__init_promise) return this.__init_promise;
              if (!this.options.js && this.options.wasm && !this.has_wasm())
                return Promise.reject(
                  new Error(
                    'mathlib: only "wasm" was enabled, but it\'s not supported'
                  )
                );
              var t = this;
              return (
                (this.__init_promise = Promise.all(
                  Object.keys(t.__modules).map(function (e) {
                    var i = t.__modules[e];
                    return t.options.wasm && t.has_wasm() && i.wasm_fn
                      ? t.__wasm[e]
                        ? null
                        : WebAssembly.compile(
                            t.__base64decode(i.wasm_src)
                          ).then(function (i) {
                            t.__wasm[e] = i;
                          })
                      : null;
                  })
                ).then(function () {
                  return t;
                })),
                this.__init_promise
              );
            }),
            (A.prototype.__base64decode = n),
            (A.prototype.__reallocate = function (t) {
              if (!this.__memory)
                return (
                  (this.__memory = new WebAssembly.Memory({
                    initial: Math.ceil(t / 65536),
                  })),
                  this.__memory
                );
              var e = this.__memory.buffer.byteLength;
              return (
                e < t && this.__memory.grow(Math.ceil((t - e) / 65536)),
                this.__memory
              );
            }),
            (A.prototype.__instance = function (t, e, i) {
              if ((e && this.__reallocate(e), !this.__wasm[t])) {
                var n = this.__modules[t];
                this.__wasm[t] = new WebAssembly.Module(
                  this.__base64decode(n.wasm_src)
                );
              }
              if (!this.__cache[t]) {
                var o = {
                  memoryBase: 0,
                  memory: this.__memory,
                  tableBase: 0,
                  table: new WebAssembly.Table({
                    initial: 0,
                    element: "anyfunc",
                  }),
                };
                this.__cache[t] = new WebAssembly.Instance(this.__wasm[t], {
                  env: r(o, i || {}),
                });
              }
              return this.__cache[t];
            }),
            (A.prototype.__align = function (t, e) {
              var i = t % (e = e || 8);
              return t + (i ? e - i : 0);
            }),
            (e.exports = A);
        },
        {
          "./lib/base64decode": 17,
          "./lib/wa_detect": 23,
          "object-assign": 24,
        },
      ],
      17: [
        function (t, e, i) {
          "use strict";
          e.exports = function (t) {
            for (
              var e = t.replace(/[\r\n=]/g, ""),
                i = e.length,
                r = new Uint8Array((3 * i) >> 2),
                n = 0,
                o = 0,
                a = 0;
              a < i;
              a++
            )
              a % 4 == 0 &&
                a &&
                ((r[o++] = (n >> 16) & 255),
                (r[o++] = (n >> 8) & 255),
                (r[o++] = 255 & n)),
                (n =
                  (n << 6) |
                  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".indexOf(
                    e.charAt(a)
                  ));
            var A = (i % 4) * 6;
            return (
              0 === A
                ? ((r[o++] = (n >> 16) & 255),
                  (r[o++] = (n >> 8) & 255),
                  (r[o++] = 255 & n))
                : 18 === A
                ? ((r[o++] = (n >> 10) & 255), (r[o++] = (n >> 2) & 255))
                : 12 === A && (r[o++] = (n >> 4) & 255),
              r
            );
          };
        },
        {},
      ],
      18: [
        function (t, e, i) {
          "use strict";
          e.exports = function (t, e, i) {
            for (
              var r, n, o, a, A, s = e * i, u = new Uint16Array(s), h = 0;
              h < s;
              h++
            )
              (r = t[4 * h]),
                (n = t[4 * h + 1]),
                (o = t[4 * h + 2]),
                (A = r >= n && r >= o ? r : n >= o && n >= r ? n : o),
                (a = r <= n && r <= o ? r : n <= o && n <= r ? n : o),
                (u[h] = (257 * (A + a)) >> 1);
            return u;
          };
        },
        {},
      ],
      19: [
        function (t, e, i) {
          "use strict";
          e.exports = {
            name: "unsharp_mask",
            fn: t("./unsharp_mask"),
            wasm_fn: t("./unsharp_mask_wasm"),
            wasm_src: t("./unsharp_mask_wasm_base64"),
          };
        },
        {
          "./unsharp_mask": 20,
          "./unsharp_mask_wasm": 21,
          "./unsharp_mask_wasm_base64": 22,
        },
      ],
      20: [
        function (t, e, i) {
          "use strict";
          var r = t("glur/mono16"),
            n = t("./hsl_l16");
          e.exports = function (t, e, i, o, a, A) {
            var s, u, h, f, c, l, g, I, d, m, p, w, B;
            if (!(0 === o || a < 0.5)) {
              a > 2 && (a = 2);
              var b = n(t, e, i),
                y = new Uint16Array(b);
              r(y, e, i, a);
              for (
                var _ = ((o / 100) * 4096 + 0.5) | 0,
                  E = (257 * A) | 0,
                  C = e * i,
                  v = 0;
                v < C;
                v++
              )
                (w = 2 * (b[v] - y[v])),
                  Math.abs(w) >= E &&
                    ((s = t[(B = 4 * v)]),
                    (u = t[B + 1]),
                    (h = t[B + 2]),
                    (l =
                      (257 *
                        ((I = s >= u && s >= h ? s : u >= s && u >= h ? u : h) +
                          (g =
                            s <= u && s <= h
                              ? s
                              : u <= s && u <= h
                              ? u
                              : h))) >>
                      1),
                    g === I
                      ? (f = c = 0)
                      : ((c =
                          l <= 32767
                            ? ((4095 * (I - g)) / (I + g)) | 0
                            : ((4095 * (I - g)) / (510 - I - g)) | 0),
                        (f =
                          s === I
                            ? ((65535 * (u - h)) / (6 * (I - g))) | 0
                            : u === I
                            ? 21845 + (((65535 * (h - s)) / (6 * (I - g))) | 0)
                            : 43690 +
                              (((65535 * (s - u)) / (6 * (I - g))) | 0))),
                    (l += (_ * w + 2048) >> 12) > 65535
                      ? (l = 65535)
                      : l < 0 && (l = 0),
                    0 === c
                      ? (s = u = h = l >> 8)
                      : ((d =
                          (2 * l -
                            (m =
                              l <= 32767
                                ? (l * (4096 + c) + 2048) >> 12
                                : l + (((65535 - l) * c + 2048) >> 12))) >>
                          8),
                        (m >>= 8),
                        (s =
                          (p = (f + 21845) & 65535) >= 43690
                            ? d
                            : p >= 32767
                            ? d + ((6 * (m - d) * (43690 - p) + 32768) >> 16)
                            : p >= 10922
                            ? m
                            : d + ((6 * (m - d) * p + 32768) >> 16)),
                        (u =
                          (p = 65535 & f) >= 43690
                            ? d
                            : p >= 32767
                            ? d + ((6 * (m - d) * (43690 - p) + 32768) >> 16)
                            : p >= 10922
                            ? m
                            : d + ((6 * (m - d) * p + 32768) >> 16)),
                        (h =
                          (p = (f - 21845) & 65535) >= 43690
                            ? d
                            : p >= 32767
                            ? d + ((6 * (m - d) * (43690 - p) + 32768) >> 16)
                            : p >= 10922
                            ? m
                            : d + ((6 * (m - d) * p + 32768) >> 16))),
                    (t[B] = s),
                    (t[B + 1] = u),
                    (t[B + 2] = h));
            }
          };
        },
        { "./hsl_l16": 18, "glur/mono16": 14 },
      ],
      21: [
        function (t, e, i) {
          "use strict";
          e.exports = function (t, e, i, r, n, o) {
            if (!(0 === r || n < 0.5)) {
              n > 2 && (n = 2);
              var a = e * i,
                A = 4 * a,
                s = 2 * a,
                u = 2 * a,
                h = 4 * Math.max(e, i),
                f = A,
                c = f + s,
                l = c + u,
                g = l + u,
                I = g + h,
                d = this.__instance("unsharp_mask", A + s + 2 * u + h + 32, {
                  exp: Math.exp,
                }),
                m = new Uint32Array(t.buffer);
              new Uint32Array(this.__memory.buffer).set(m);
              var p = d.exports.hsl_l16 || d.exports._hsl_l16;
              p(0, f, e, i),
                (p = d.exports.blurMono16 || d.exports._blurMono16)(
                  f,
                  c,
                  l,
                  g,
                  I,
                  e,
                  i,
                  n
                ),
                (p = d.exports.unsharp || d.exports._unsharp)(
                  0,
                  0,
                  f,
                  c,
                  e,
                  i,
                  r,
                  o
                ),
                m.set(new Uint32Array(this.__memory.buffer, 0, a));
            }
          };
        },
        {},
      ],
      22: [
        function (t, e, i) {
          "use strict";
          e.exports =
            "AGFzbQEAAAABMQZgAXwBfGACfX8AYAZ/f39/f38AYAh/f39/f39/fQBgBH9/f38AYAh/f39/f39/fwACGQIDZW52A2V4cAAAA2VudgZtZW1vcnkCAAEDBgUBAgMEBQQEAXAAAAdMBRZfX2J1aWxkX2dhdXNzaWFuX2NvZWZzAAEOX19nYXVzczE2X2xpbmUAAgpibHVyTW9ubzE2AAMHaHNsX2wxNgAEB3Vuc2hhcnAABQkBAAqJEAXZAQEGfAJAIAFE24a6Q4Ia+z8gALujIgOaEAAiBCAEoCIGtjgCECABIANEAAAAAAAAAMCiEAAiBbaMOAIUIAFEAAAAAAAA8D8gBKEiAiACoiAEIAMgA6CiRAAAAAAAAPA/oCAFoaMiArY4AgAgASAEIANEAAAAAAAA8L+gIAKioiIHtjgCBCABIAQgA0QAAAAAAADwP6AgAqKiIgO2OAIIIAEgBSACoiIEtow4AgwgASACIAegIAVEAAAAAAAA8D8gBqGgIgKjtjgCGCABIAMgBKEgAqO2OAIcCwu3AwMDfwR9CHwCQCADKgIUIQkgAyoCECEKIAMqAgwhCyADKgIIIQwCQCAEQX9qIgdBAEgiCA0AIAIgAC8BALgiDSADKgIYu6IiDiAJuyIQoiAOIAq7IhGiIA0gAyoCBLsiEqIgAyoCALsiEyANoqCgoCIPtjgCACACQQRqIQIgAEECaiEAIAdFDQAgBCEGA0AgAiAOIBCiIA8iDiARoiANIBKiIBMgAC8BALgiDaKgoKAiD7Y4AgAgAkEEaiECIABBAmohACAGQX9qIgZBAUoNAAsLAkAgCA0AIAEgByAFbEEBdGogAEF+ai8BACIIuCINIAu7IhGiIA0gDLsiEqKgIA0gAyoCHLuiIg4gCrsiE6KgIA4gCbsiFKKgIg8gAkF8aioCALugqzsBACAHRQ0AIAJBeGohAiAAQXxqIQBBACAFQQF0ayEHIAEgBSAEQQF0QXxqbGohBgNAIAghAyAALwEAIQggBiANIBGiIAO4Ig0gEqKgIA8iECAToqAgDiAUoqAiDyACKgIAu6CrOwEAIAYgB2ohBiAAQX5qIQAgAkF8aiECIBAhDiAEQX9qIgRBAUoNAAsLCwvfAgIDfwZ8AkAgB0MAAAAAWw0AIARE24a6Q4Ia+z8gB0MAAAA/l7ujIgyaEAAiDSANoCIPtjgCECAEIAxEAAAAAAAAAMCiEAAiDraMOAIUIAREAAAAAAAA8D8gDaEiCyALoiANIAwgDKCiRAAAAAAAAPA/oCAOoaMiC7Y4AgAgBCANIAxEAAAAAAAA8L+gIAuioiIQtjgCBCAEIA0gDEQAAAAAAADwP6AgC6KiIgy2OAIIIAQgDiALoiINtow4AgwgBCALIBCgIA5EAAAAAAAA8D8gD6GgIgujtjgCGCAEIAwgDaEgC6O2OAIcIAYEQCAFQQF0IQogBiEJIAIhCANAIAAgCCADIAQgBSAGEAIgACAKaiEAIAhBAmohCCAJQX9qIgkNAAsLIAVFDQAgBkEBdCEIIAUhAANAIAIgASADIAQgBiAFEAIgAiAIaiECIAFBAmohASAAQX9qIgANAAsLC7wBAQV/IAMgAmwiAwRAQQAgA2shBgNAIAAoAgAiBEEIdiIHQf8BcSECAn8gBEH/AXEiAyAEQRB2IgRB/wFxIgVPBEAgAyIIIAMgAk8NARoLIAQgBCAHIAIgA0kbIAIgBUkbQf8BcQshCAJAIAMgAk0EQCADIAVNDQELIAQgByAEIAMgAk8bIAIgBUsbQf8BcSEDCyAAQQRqIQAgASADIAhqQYECbEEBdjsBACABQQJqIQEgBkEBaiIGDQALCwvTBgEKfwJAIAazQwAAgEWUQwAAyEKVu0QAAAAAAADgP6CqIQ0gBSAEbCILBEAgB0GBAmwhDgNAQQAgAi8BACADLwEAayIGQQF0IgdrIAcgBkEASBsgDk8EQCAAQQJqLQAAIQUCfyAALQAAIgYgAEEBai0AACIESSIJRQRAIAYiCCAGIAVPDQEaCyAFIAUgBCAEIAVJGyAGIARLGwshCAJ/IAYgBE0EQCAGIgogBiAFTQ0BGgsgBSAFIAQgBCAFSxsgCRsLIgogCGoiD0GBAmwiEEEBdiERQQAhDAJ/QQAiCSAIIApGDQAaIAggCmsiCUH/H2wgD0H+AyAIayAKayAQQYCABEkbbSEMIAYgCEYEQCAEIAVrQf//A2wgCUEGbG0MAQsgBSAGayAGIARrIAQgCEYiBhtB//8DbCAJQQZsbUHVqgFBqtUCIAYbagshCSARIAcgDWxBgBBqQQx1aiIGQQAgBkEAShsiBkH//wMgBkH//wNIGyEGAkACfwJAIAxB//8DcSIFBEAgBkH//wFKDQEgBUGAIGogBmxBgBBqQQx2DAILIAZBCHYiBiEFIAYhBAwCCyAFIAZB//8Dc2xBgBBqQQx2IAZqCyIFQQh2IQcgBkEBdCAFa0EIdiIGIQQCQCAJQdWqAWpB//8DcSIFQanVAksNACAFQf//AU8EQEGq1QIgBWsgByAGa2xBBmxBgIACakEQdiAGaiEEDAELIAchBCAFQanVAEsNACAFIAcgBmtsQQZsQYCAAmpBEHYgBmohBAsCfyAGIgUgCUH//wNxIghBqdUCSw0AGkGq1QIgCGsgByAGa2xBBmxBgIACakEQdiAGaiAIQf//AU8NABogByIFIAhBqdUASw0AGiAIIAcgBmtsQQZsQYCAAmpBEHYgBmoLIQUgCUGr1QJqQf//A3EiCEGp1QJLDQAgCEH//wFPBEBBqtUCIAhrIAcgBmtsQQZsQYCAAmpBEHYgBmohBgwBCyAIQanVAEsEQCAHIQYMAQsgCCAHIAZrbEEGbEGAgAJqQRB2IAZqIQYLIAEgBDoAACABQQFqIAU6AAAgAUECaiAGOgAACyADQQJqIQMgAkECaiECIABBBGohACABQQRqIQEgC0F/aiILDQALCwsL";
        },
        {},
      ],
      23: [
        function (t, e, i) {
          "use strict";
          var r;
          e.exports = function () {
            if (void 0 !== r) return r;
            if (((r = !1), "undefined" == typeof WebAssembly)) return r;
            try {
              var t = new Uint8Array([
                  0, 97, 115, 109, 1, 0, 0, 0, 1, 6, 1, 96, 1, 127, 1, 127, 3,
                  2, 1, 0, 5, 3, 1, 0, 1, 7, 8, 1, 4, 116, 101, 115, 116, 0, 0,
                  10, 16, 1, 14, 0, 32, 0, 65, 1, 54, 2, 0, 32, 0, 40, 2, 0, 11,
                ]),
                e = new WebAssembly.Module(t);
              return (
                0 !== new WebAssembly.Instance(e, {}).exports.test(4) &&
                  (r = !0),
                r
              );
            } catch (t) {}
            return r;
          };
        },
        {},
      ],
      24: [
        function (t, e, i) {
          /*
object-assign
(c) Sindre Sorhus
@license MIT
*/
          "use strict";
          var r = Object.getOwnPropertySymbols,
            n = Object.prototype.hasOwnProperty,
            o = Object.prototype.propertyIsEnumerable;
          function a(t) {
            if (null == t)
              throw new TypeError(
                "Object.assign cannot be called with null or undefined"
              );
            return Object(t);
          }
          e.exports = (function () {
            try {
              if (!Object.assign) return !1;
              var t = new String("abc");
              if (((t[5] = "de"), "5" === Object.getOwnPropertyNames(t)[0]))
                return !1;
              for (var e = {}, i = 0; i < 10; i++)
                e["_" + String.fromCharCode(i)] = i;
              if (
                "0123456789" !==
                Object.getOwnPropertyNames(e)
                  .map(function (t) {
                    return e[t];
                  })
                  .join("")
              )
                return !1;
              var r = {};
              return (
                "abcdefghijklmnopqrst".split("").forEach(function (t) {
                  r[t] = t;
                }),
                "abcdefghijklmnopqrst" ===
                  Object.keys(Object.assign({}, r)).join("")
              );
            } catch (t) {
              return !1;
            }
          })()
            ? Object.assign
            : function (t, e) {
                for (var i, A, s = a(t), u = 1; u < arguments.length; u++) {
                  for (var h in (i = Object(arguments[u])))
                    n.call(i, h) && (s[h] = i[h]);
                  if (r) {
                    A = r(i);
                    for (var f = 0; f < A.length; f++)
                      o.call(i, A[f]) && (s[A[f]] = i[A[f]]);
                  }
                }
                return s;
              };
        },
        {},
      ],
      25: [
        function (t, e, i) {
          var r = arguments[3],
            n = arguments[4],
            o = arguments[5],
            a = JSON.stringify;
          e.exports = function (t, e) {
            for (var i, A = Object.keys(o), s = 0, u = A.length; s < u; s++) {
              var h = A[s],
                f = o[h].exports;
              if (f === t || (f && f.default === t)) {
                i = h;
                break;
              }
            }
            if (!i) {
              i = Math.floor(Math.pow(16, 8) * Math.random()).toString(16);
              var c = {};
              for (s = 0, u = A.length; s < u; s++) {
                c[(h = A[s])] = h;
              }
              n[i] = ["function(require,module,exports){" + t + "(self); }", c];
            }
            var l = Math.floor(Math.pow(16, 8) * Math.random()).toString(16),
              g = {};
            (g[i] = i),
              (n[l] = [
                "function(require,module,exports){var f = require(" +
                  a(i) +
                  ");(f.default ? f.default : f)(self);}",
                g,
              ]);
            var I = {};
            !(function t(e) {
              for (var i in ((I[e] = !0), n[e][1])) {
                var r = n[e][1][i];
                I[r] || t(r);
              }
            })(l);
            var d =
                "(" +
                r +
                ")({" +
                Object.keys(I)
                  .map(function (t) {
                    return a(t) + ":[" + n[t][0] + "," + a(n[t][1]) + "]";
                  })
                  .join(",") +
                "},{},[" +
                a(l) +
                "])",
              m =
                window.URL || window.webkitURL || window.mozURL || window.msURL,
              p = new Blob([d], { type: "text/javascript" });
            if (e && e.bare) return p;
            var w = m.createObjectURL(p),
              B = new Worker(w);
            return (B.objectURL = w), B;
          };
        },
        {},
      ],
      "/index.js": [
        function (t, e, i) {
          "use strict";
          function r(t, e) {
            return (
              (function (t) {
                if (Array.isArray(t)) return t;
              })(t) ||
              (function (t, e) {
                if (
                  "undefined" == typeof Symbol ||
                  !(Symbol.iterator in Object(t))
                )
                  return;
                var i = [],
                  r = !0,
                  n = !1,
                  o = void 0;
                try {
                  for (
                    var a, A = t[Symbol.iterator]();
                    !(r = (a = A.next()).done) &&
                    (i.push(a.value), !e || i.length !== e);
                    r = !0
                  );
                } catch (t) {
                  (n = !0), (o = t);
                } finally {
                  try {
                    r || null == A.return || A.return();
                  } finally {
                    if (n) throw o;
                  }
                }
                return i;
              })(t, e) ||
              (function (t, e) {
                if (!t) return;
                if ("string" == typeof t) return n(t, e);
                var i = Object.prototype.toString.call(t).slice(8, -1);
                "Object" === i && t.constructor && (i = t.constructor.name);
                if ("Map" === i || "Set" === i) return Array.from(t);
                if (
                  "Arguments" === i ||
                  /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)
                )
                  return n(t, e);
              })(t, e) ||
              (function () {
                throw new TypeError(
                  "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                );
              })()
            );
          }
          function n(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var i = 0, r = new Array(e); i < e; i++) r[i] = t[i];
            return r;
          }
          var o = t("object-assign"),
            a = t("webworkify"),
            A = t("./lib/mathlib"),
            s = t("./lib/pool"),
            u = t("./lib/utils"),
            h = t("./lib/worker"),
            f = t("./lib/stepper"),
            c = t("./lib/tiler"),
            l = {},
            g = !1;
          try {
            "undefined" != typeof navigator &&
              navigator.userAgent &&
              (g = navigator.userAgent.indexOf("Safari") >= 0);
          } catch (t) {}
          var I = 1;
          "undefined" != typeof navigator &&
            (I = Math.min(navigator.hardwareConcurrency || 1, 4));
          var d,
            m,
            p = {
              tile: 1024,
              concurrency: I,
              features: ["js", "wasm", "ww"],
              idle: 2e3,
              createCanvas: function (t, e) {
                var i = document.createElement("canvas");
                return (i.width = t), (i.height = e), i;
              },
            },
            w = {
              quality: 3,
              alpha: !1,
              unsharpAmount: 0,
              unsharpRadius: 0,
              unsharpThreshold: 0,
            };
          function B() {
            return {
              value: a(h),
              destroy: function () {
                if ((this.value.terminate(), "undefined" != typeof window)) {
                  var t =
                    window.URL ||
                    window.webkitURL ||
                    window.mozURL ||
                    window.msURL;
                  t &&
                    t.revokeObjectURL &&
                    this.value.objectURL &&
                    t.revokeObjectURL(this.value.objectURL);
                }
              },
            };
          }
          function b(t) {
            if (!(this instanceof b)) return new b(t);
            this.options = o({}, p, t || {});
            var e = "lk_".concat(this.options.concurrency);
            (this.__limit = l[e] || u.limiter(this.options.concurrency)),
              l[e] || (l[e] = this.__limit),
              (this.features = { js: !1, wasm: !1, cib: !1, ww: !1 }),
              (this.__workersPool = null),
              (this.__requested_features = []),
              (this.__mathlib = null);
          }
          (b.prototype.init = function () {
            var e = this;
            if (this.__initPromise) return this.__initPromise;
            if (
              !1 !== d &&
              !0 !== d &&
              ((d = !1),
              "undefined" != typeof ImageData &&
                "undefined" != typeof Uint8ClampedArray)
            )
              try {
                new ImageData(new Uint8ClampedArray(400), 10, 10), (d = !0);
              } catch (t) {}
            !1 !== m &&
              !0 !== m &&
              ((m = !1),
              "undefined" != typeof ImageBitmap &&
                (ImageBitmap.prototype && ImageBitmap.prototype.close
                  ? (m = !0)
                  : this.debug(
                      "ImageBitmap does not support .close(), disabled"
                    )));
            var i = this.options.features.slice();
            if (
              (i.indexOf("all") >= 0 && (i = ["cib", "wasm", "js", "ww"]),
              (this.__requested_features = i),
              (this.__mathlib = new A(i)),
              i.indexOf("ww") >= 0 &&
                "undefined" != typeof window &&
                "Worker" in window)
            )
              try {
                t("webworkify")(function () {}).terminate(),
                  (this.features.ww = !0);
                var r = "wp_".concat(JSON.stringify(this.options));
                l[r]
                  ? (this.__workersPool = l[r])
                  : ((this.__workersPool = new s(B, this.options.idle)),
                    (l[r] = this.__workersPool));
              } catch (t) {}
            var n,
              a = this.__mathlib.init().then(function (t) {
                o(e.features, t.features);
              });
            return (
              (n = m
                ? u.cib_support(this.options.createCanvas).then(function (t) {
                    e.features.cib && i.indexOf("cib") < 0
                      ? e.debug(
                          "createImageBitmap() resize supported, but disabled by config"
                        )
                      : i.indexOf("cib") >= 0 && (e.features.cib = t);
                  })
                : Promise.resolve(!1)),
              (this.__initPromise = Promise.all([a, n]).then(function () {
                return e;
              })),
              this.__initPromise
            );
          }),
            (b.prototype.resize = function (t, e, i) {
              var n = this;
              this.debug("Start resize...");
              var a = o({}, w);
              if (
                (isNaN(i) ? i && (a = o(a, i)) : (a = o(a, { quality: i })),
                (a.toWidth = e.width),
                (a.toHeight = e.height),
                (a.width = t.naturalWidth || t.width),
                (a.height = t.naturalHeight || t.height),
                0 === e.width || 0 === e.height)
              )
                return Promise.reject(
                  new Error(
                    "Invalid output size: "
                      .concat(e.width, "x")
                      .concat(e.height)
                  )
                );
              a.unsharpRadius > 2 && (a.unsharpRadius = 2);
              var A = !1,
                s = null;
              a.cancelToken &&
                (s = a.cancelToken.then(
                  function (t) {
                    throw ((A = !0), t);
                  },
                  function (t) {
                    throw ((A = !0), t);
                  }
                ));
              var h = Math.ceil(Math.max(3, (2.5 * a.unsharpRadius) | 0));
              return this.init().then(function () {
                if (A) return s;
                if (n.features.cib) {
                  var i = e.getContext("2d", { alpha: Boolean(a.alpha) });
                  return (
                    n.debug("Resize via createImageBitmap()"),
                    createImageBitmap(t, {
                      resizeWidth: a.toWidth,
                      resizeHeight: a.toHeight,
                      resizeQuality: u.cib_quality_name(a.quality),
                    }).then(function (t) {
                      if (A) return s;
                      if (!a.unsharpAmount)
                        return (
                          i.drawImage(t, 0, 0),
                          t.close(),
                          (i = null),
                          n.debug("Finished!"),
                          e
                        );
                      n.debug("Unsharp result");
                      var r = n.options.createCanvas(a.toWidth, a.toHeight),
                        o = r.getContext("2d", { alpha: Boolean(a.alpha) });
                      o.drawImage(t, 0, 0), t.close();
                      var u = o.getImageData(0, 0, a.toWidth, a.toHeight);
                      return (
                        n.__mathlib.unsharp_mask(
                          u.data,
                          a.toWidth,
                          a.toHeight,
                          a.unsharpAmount,
                          a.unsharpRadius,
                          a.unsharpThreshold
                        ),
                        i.putImageData(u, 0, 0),
                        (r.width = r.height = 0),
                        (u = o = r = i = null),
                        n.debug("Finished!"),
                        e
                      );
                    })
                  );
                }
                var l = {},
                  I = function (t, e, i) {
                    var r,
                      o,
                      a,
                      f = !1,
                      I = function (e) {
                        return n.__limit(function () {
                          if (A) return s;
                          var h;
                          if (u.isCanvas(t))
                            n.debug("Get tile pixel data"),
                              (h = r.getImageData(e.x, e.y, e.width, e.height));
                          else {
                            n.debug(
                              "Draw tile imageBitmap/image to temporary canvas"
                            );
                            var f = n.options.createCanvas(e.width, e.height),
                              c = f.getContext("2d", {
                                alpha: Boolean(i.alpha),
                              });
                            (c.globalCompositeOperation = "copy"),
                              c.drawImage(
                                o || t,
                                e.x,
                                e.y,
                                e.width,
                                e.height,
                                0,
                                0,
                                e.width,
                                e.height
                              ),
                              n.debug("Get tile pixel data"),
                              (h = c.getImageData(0, 0, e.width, e.height)),
                              (f.width = f.height = 0),
                              (c = f = null);
                          }
                          var I = {
                            src: h.data,
                            width: e.width,
                            height: e.height,
                            toWidth: e.toWidth,
                            toHeight: e.toHeight,
                            scaleX: e.scaleX,
                            scaleY: e.scaleY,
                            offsetX: e.offsetX,
                            offsetY: e.offsetY,
                            quality: i.quality,
                            alpha: i.alpha,
                            unsharpAmount: i.unsharpAmount,
                            unsharpRadius: i.unsharpRadius,
                            unsharpThreshold: i.unsharpThreshold,
                          };
                          return (
                            n.debug("Invoke resize math"),
                            Promise.resolve()
                              .then(function () {
                                return (function (t) {
                                  return Promise.resolve().then(function () {
                                    return n.features.ww
                                      ? new Promise(function (e, i) {
                                          var r = n.__workersPool.acquire();
                                          s &&
                                            s.catch(function (t) {
                                              return i(t);
                                            }),
                                            (r.value.onmessage = function (t) {
                                              r.release(),
                                                t.data.err
                                                  ? i(t.data.err)
                                                  : e(t.data.result);
                                            }),
                                            r.value.postMessage(
                                              {
                                                opts: t,
                                                features:
                                                  n.__requested_features,
                                                preload: {
                                                  wasm_nodule: n.__mathlib.__,
                                                },
                                              },
                                              [t.src.buffer]
                                            );
                                        })
                                      : n.__mathlib.resizeAndUnsharp(t, l);
                                  });
                                })(I);
                              })
                              .then(function (t) {
                                if (A) return s;
                                var i;
                                if (
                                  ((h = null),
                                  n.debug(
                                    "Convert raw rgba tile result to ImageData"
                                  ),
                                  d)
                                )
                                  i = new ImageData(
                                    new Uint8ClampedArray(t),
                                    e.toWidth,
                                    e.toHeight
                                  );
                                else if (
                                  (i = a.createImageData(e.toWidth, e.toHeight))
                                    .data.set
                                )
                                  i.data.set(t);
                                else
                                  for (var r = i.data.length - 1; r >= 0; r--)
                                    i.data[r] = t[r];
                                return (
                                  n.debug("Draw tile"),
                                  g
                                    ? a.putImageData(
                                        i,
                                        e.toX,
                                        e.toY,
                                        e.toInnerX - e.toX,
                                        e.toInnerY - e.toY,
                                        e.toInnerWidth + 1e-5,
                                        e.toInnerHeight + 1e-5
                                      )
                                    : a.putImageData(
                                        i,
                                        e.toX,
                                        e.toY,
                                        e.toInnerX - e.toX,
                                        e.toInnerY - e.toY,
                                        e.toInnerWidth,
                                        e.toInnerHeight
                                      ),
                                  null
                                );
                              })
                          );
                        });
                      };
                    return Promise.resolve()
                      .then(function () {
                        if (
                          ((a = e.getContext("2d", {
                            alpha: Boolean(i.alpha),
                          })),
                          u.isCanvas(t))
                        )
                          return (
                            (r = t.getContext("2d", {
                              alpha: Boolean(i.alpha),
                            })),
                            null
                          );
                        if (u.isImageBitmap(t)) return (o = t), (f = !0), null;
                        if (u.isImage(t))
                          return m
                            ? (n.debug("Decode image via createImageBitmap"),
                              createImageBitmap(t)
                                .then(function (t) {
                                  o = t;
                                })
                                .catch(function (t) {
                                  return null;
                                }))
                            : null;
                        throw new Error(
                          'Pica: ".from" should be Image, Canvas or ImageBitmap'
                        );
                      })
                      .then(function () {
                        if (A) return s;
                        n.debug("Calculate tiles");
                        var t = c({
                          width: i.width,
                          height: i.height,
                          srcTileSize: n.options.tile,
                          toWidth: i.toWidth,
                          toHeight: i.toHeight,
                          destTileBorder: h,
                        }).map(function (t) {
                          return I(t);
                        });
                        function r() {
                          o && (f || o.close(), (o = null));
                        }
                        return (
                          n.debug("Process tiles"),
                          Promise.all(t).then(
                            function () {
                              return n.debug("Finished!"), r(), e;
                            },
                            function (t) {
                              throw (r(), t);
                            }
                          )
                        );
                      });
                  };
                return (function t(e, i, a, u) {
                  if (A) return s;
                  var h,
                    f = r(e.shift(), 2),
                    c = f[0],
                    l = f[1],
                    g = 0 === e.length;
                  return (
                    (u = o({}, u, {
                      toWidth: c,
                      toHeight: l,
                      quality: g ? u.quality : Math.min(1, u.quality),
                    })),
                    g || (h = n.options.createCanvas(c, l)),
                    I(i, g ? a : h, u)
                      .then(function () {
                        return g
                          ? a
                          : ((u.width = c), (u.height = l), t(e, h, a, u));
                      })
                      .then(function (t) {
                        return h && (h.width = h.height = 0), t;
                      })
                  );
                })(
                  f(
                    a.width,
                    a.height,
                    a.toWidth,
                    a.toHeight,
                    n.options.tile,
                    h
                  ),
                  t,
                  e,
                  a
                );
              });
            }),
            (b.prototype.resizeBuffer = function (t) {
              var e = this,
                i = o({}, w, t);
              return this.init().then(function () {
                return e.__mathlib.resizeAndUnsharp(i);
              });
            }),
            (b.prototype.toBlob = function (t, e, i) {
              return (
                (e = e || "image/png"),
                new Promise(function (r) {
                  if (t.toBlob)
                    t.toBlob(
                      function (t) {
                        return r(t);
                      },
                      e,
                      i
                    );
                  else if (t.convertToBlob)
                    r(t.convertToBlob({ type: e, quality: i }));
                  else {
                    for (
                      var n = atob(t.toDataURL(e, i).split(",")[1]),
                        o = n.length,
                        a = new Uint8Array(o),
                        A = 0;
                      A < o;
                      A++
                    )
                      a[A] = n.charCodeAt(A);
                    r(new Blob([a], { type: e }));
                  }
                })
              );
            }),
            (b.prototype.debug = function () {}),
            (e.exports = b);
        },
        {
          "./lib/mathlib": 1,
          "./lib/pool": 9,
          "./lib/stepper": 10,
          "./lib/tiler": 11,
          "./lib/utils": 12,
          "./lib/worker": 13,
          "object-assign": 24,
          webworkify: 25,
        },
      ],
    },
    {},
    []
  )("/index.js");
});

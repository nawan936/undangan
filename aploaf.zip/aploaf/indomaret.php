
<!DOCTYPE html>

<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<head>

    <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1">


<title>Undangan Acara Pernikahan Ali Sandi, S.P &amp; Ays, S.Pd</title>


    <!-- Facebook and Twitter integration -->
<meta property="og:type" content="article" />
<meta property="og:title" content="Pernikahan Ali Sandi, S.P &amp; Ays, S.Pd"/>




<meta property="og:description" content="Pernikahan Ali Sandi, S.P &amp; Ays, S.Pd"/>
<meta name="facebook-domain-verification" content="zr3wk2z3msa7y7eq063nbt71rr7gqo" />

<meta name='robots' content='noindex, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
<meta name="description" content="Pernikahan Ali Sandi, S.P &amp; Ays, S.Pd" />
<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
<meta name="viewport" content="width=device-width,initial-scale=1">


<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>



<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-NPGJWXK');</script>
<!-- End Google Tag Manager -->


<meta name="csrf-token" content="l5JWjBT2gJYijjEfxPW4VCU9wpIp4zTVYhWhwAfE">

<link href='https://fonts.googleapis.com/css?family=Work+Sans:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Sacramento" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Waterfall&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Saira+Extra+Condensed:wght@600&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Golos+Text&display=swap" rel="stylesheet">


<!-- tambahan -->
 <meta property="og:type" content="website" />
<meta property="og:title" content="Undangan Pernikahan Ali Sandi, S.P & Ays, S.Pd" />
<meta property="og:description" content="Dengan memohon rahmat Allah SWT, kami bermaksud mengundang Bapak/Ibu/Saudara/i untuk hadir dalam acara pernikahan kami." />
<meta property="og:image" content="https://nawanframe.store/undangansevi/img2/1.jpeg" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta property="og:url" content="https://nawanframe.store/undangansevi/" />
<meta property="og:site_name" content="Undangan Pernikahan" />

<!-- tambahan -->


<link href="https://fonts.googleapis.com/css2?family=Averia+Serif+Libre&family=Poppins&display=swap" rel="stylesheet">


<script src="https://www.youtube.com/iframe_api"></script>

<!-- baru -->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="undangan1a.css">
<!-- baru -->


    <!--====== Favicon Icon ======-->
<link rel="apple-touch-icon" sizes="180x180" href="./img2/2.jpeg">
<link rel="icon" type="image/png" sizes="32x32" href="./img2/2.jpeg">
<link rel="icon" type="image/png" sizes="16x16" href="./img2/2.jpeg">


<!-- Animate.css -->
<link rel="stylesheet" href="undangan1animasi.css">
<!-- Icomoon Icon Fonts-->
<link rel="stylesheet" href="undangan1icon.css">
<!-- Bootstrap  -->
<link rel="stylesheet" href="undangan1bootsrap.css">

<!-- Magnific Popup -->
<link rel="stylesheet" href="undangan1popup.css">

<!-- Owl Carousel  -->
<link rel="stylesheet" href="undangan1.carousel.css">
<link rel="stylesheet" href="undangan1default.css">

<!-- Theme style  -->
<link rel="stylesheet" href="undangan1.css">

<link rel="stylesheet" href="undangan1min.css">
<link rel="stylesheet" href="undangan1min.css">


<link rel="stylesheet" href="undangan1.animation.css">

<!-- Cropper CSS -->
<link rel="stylesheet" href="undangan1cropper.css">

<!-- Modernizr JS -->
<script src="undangan1moderniz.js"></script>
<!-- FOR IE9 below -->
<!--[if lt IE 9]>
<script src="js/respond.min.js"></script>
<![endif]-->
<link href="undangan1aos.css" rel="stylesheet">


<link href="undangan1template.css" rel="stylesheet">
<link rel="stylesheet" href="undangan1tailwind.css">



<script>
window.onload = function() {
var context = new AudioContext();
}
</script>
    <link href="https://fonts.googleapis.com/css?family=Montez" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Raleway:400,500,600,700,800" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Caramel&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="undangan1fontawesome.css">

        <style>
    :root {
        --primary-color: #000000;
        --sec-color: #000000;
        --h-color: #fff;
        --p-color: #fff;
        --o-color: #e5a118;
    }

    @font-face {
        font-family: 'icomoon';
        src: url("../fonts/icomoon/icomoon.eot?srf3rx");
        src: url("../fonts/icomoon/icomoon.eot?srf3rx#iefix") format("embedded-opentype"), url("../fonts/icomoon/icomoon.ttf?srf3rx") format("truetype"), url("../fonts/icomoon/icomoon.woff?srf3rx") format("woff"), url("../fonts/icomoon/icomoon.svg?srf3rx#icomoon") format("svg");
        font-weight: normal;
        font-style: normal;
    }

    /* =======================================================
  *
  * 	Template Style
  *	Edit this section
  *
  * ======================================================= */
    body {
        font-family: "Open Sans", Arial, sans-serif;
        line-height: 1.6;
        font-size: 16px;
        background: #848484;
        color: var(--p-color);
        font-weight: 300;
        overflow-x: hidden;
    }

    body.fh5co-offcanvas {
        overflow: hidden;
    }

    a {
        color: #F69D9D;
        -webkit-transition: 0.5s, ease;
        -o-transition: 0.5s, ease;
        transition: 0.5s, ease;
    }

    a:hover {
        text-decoration: none;
        color: #F69D9D;
    }

    p,
    ul,
    ol {
        /* margin-bottom: 1.5em; */
        /* font-size: 16px; */
        /* color: #848484; */
                    font-family: "Open Sans", Arial, sans-serif;
            }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {

        color: #5a5a5a;
                    font-family: 'Caramel', cursive;
                font-weight: 400;
        margin: 0 0 30px 0;
    }

    figure {
        margin-bottom: 2em;
    }

    ::-webkit-selection {
        color: #fcfcfc;
        background: #F69D9D;
    }

    ::-moz-selection {
        color: #fcfcfc;
        background: #F69D9D;
    }

    ::selection {
        color: #fcfcfc;
        background: #F69D9D;
    }

    /* Styling */
    .mob-con {
        background-color: var(--primary-color);
    }

    .awal {
        background-color: #000000;
        z-index: 999999;
        /* height: 100vh; */
        position: fixed;
        right: 0;
        left: 0;
        top: 0;
        bottom: 0;
        text-align: center;
        /* height: 100vh; */
    }

    .awal h1{
        /* font-family: 'Caramel', cursive; */
        font-size: 50px;
        text-align: center;
        color: white;
        margin-bottom: 0;
    }

    #box-1-date-id1{
        margin-bottom: 0;
        text-align: center;
        font-family: "Open Sans", Arial, sans-serif;
        color: white;
    }

    .btn {
        text-transform: uppercase;
        letter-spacing: 2px;
        -webkit-transition: 0.3s;
        -o-transition: 0.3s;
        transition: 0.3s;
    }

    .btn.btn-primary {
        background: #c6cedb;
        margin: 0px auto;
        color: var(--primary-color);
        font-weight: bold;
        border: rgb(0 0 0) 0px solid;
    }

    .btn:hover,
    .btn:active,
    .btn:focus {
        background: #393e46 !important;
        color: #fff;
        outline: none !important;
        border: rgb(0 0 0) 0px solid;
    }

    .box-1 {
        position: relative;
        height: auto;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: auto;
        background-color: var(--primary-Color);
        min-height: 400px;
    }

    .fh5co-cover {
        background-size: cover;
        position: relative;
        height: auto !important;
    }

    .fh5co-cover .display-t {
        display: table;
        height: auto;
        width: 100%;
        position: relative;
        z-index: 2;
        padding-top: 260px;
    }

    .fh5co-cover .display-tc {
        display: block !important;
        vertical-align: inherit;
        margin-top: 260px !important;
        height: auto;
    }

    #background-box-1{
        position: relative;
        background-image: url('./img2/1.jpeg');
        background-position: center center !important;
        z-index: 99;
        background-size: cover;
        height: 80vh;
    }

    #overlay-box-1{
        position: absolute !important;
        width: 100%;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        z-index: 1;
        background: rgba(0, 0, 0, 0.4);
    }

    #ak-fun-h1-id1{
        font-family: 'Caramel', cursive;
        font-size:70px;
        margin-bottom: 15px;
        color: #fff;
    }

    #nm-acara-fun-h1-id3, #fun-h1-id4a{
        font-family: 'Caramel', cursive;
        font-size:70px;
        margin-bottom: 15px;
        color: #fff;
    }

    .timeline-article p span svg path{
        fill: #fff;
    }
    #aca-fun-h1-id1{
        color: #fff
    }
    #aca-fun-h1-id12{
        color: #fff
    }


    .box-2 {
        height: auto;
        background-position: center top, center bottom;
        background-repeat: repeat-Y;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
        background-color: var(--primary-color);
        contain: content;
    }

    #fh5co-couple{
        padding: 4em 0;
    }

    .h-16{
        height: 1em;
    }

    #fun-div-id22 p{
        /* font-size: 14px;
        margin-bottom: 1.5em;
        font-size: 16px;
        font-family: "Open Sans", Arial, sans-serif;
        color: white; */
    }

    #c-salam-agama-id p{
        font-size: 30px;
        color: white;
    }

    #sparator i{
        font-size: 50px;
    }

    .box-3 {
        height: auto;
        background-color: var(--primary-color);
        /* contain: content; */
    }


    .box-4 {
        position: relative;
        height: auto;
        background-color: var(--primary-color);
    }

    #fh5co-when-where{
        padding: 2em 0;
    }

    #c-doa-id{
        margin-left: auto;
        margin-right: auto;
        display: block;
        margin-bottom: 50px;
        margin-top:50px;
        border-radius:10%;
        box-shadow:0px 2px 15px 0px var(--p-color);
        padding:15px;
    }

    #c-doa-id p{
        color: var(--p-color);
    }

    #savedate-fun-h1-id1{
        color: var(--h-color);
        font-size: 60px;
    }

    #acara1-fun-h1-id1{
        color: var(--h-color);
        font-size: 30px;
    }

    .box-5 {
        height: auto;
        background-color: var(--primary-color);
        contain: content;
    }

    .box-6 {
        height: auto;
        position: relative;
        background-color: var(--primary-color);
    }

    .shadow{
        box-shadow: none !important;
    }
    #div-story-id1 h1,h3{
        color: var(--p-color);
    }

    .story-h3 {
        margin: 20px 0 0 0 !important;
        font-size: 25px !important;
    }

    .box-ucapan{
        color: black;
    }
    .box-ucapan p{
        margin-bottom: 0;
    }
    #fh5co-gallery{
        padding: 4em 0 !important;
    }
    .fh5co-heading {
        margin-bottom: 2em;
    }
    .fh5co-heading h2 {
        font-size: 60px;
        margin-bottom: 10px;
        line-height: 1.5;
        color: var(--h-color) !important;
    }
    #our-gallery-id3{
        font-size: 60px;
        margin-bottom: 10px;
        line-height: 1.5;
        color: var(--h-color) !important;
    }
    #titip-hadiah-tem2{
        font-size: 60px !important;
        color: var(--h-color) !important;
    }

    .rek_gambar{
        margin-bottom: 30px;
    }
    #kehadiran_text{
        font-size: 60px !important;
        color: var(--h-color) !important;
    }
    #konfir_nama_2{
        color: var(--p-color) !important;
        border: 1px solid var(--h-color) !important;
    }
    #ucapan_2{
        color: var(--p-color) !important;
        border: 1px solid var(--h-color) !important;
    }
    #hadir_id{
        color: var(--p-color) !important;
        border: 1px solid var(--h-color) !important;
    }
    .val_nohadir{
        color: var(--primary-color) !important;
    }
    .val_hadir{
        color: var(--primary-color) !important;
    }
    .akhir {
        position: relative;
        background-color: var(--primary-color);
        height: auto;
        contain: content;
    }

    #akhir-h1-id1{
        font-size: 50px !important;
        letter-spacing: 0.4px;
        color: var(--h-color);
        font-family: 'Caramel', cursive;
        font-weight: 300;
        margin-bottom: 20px !important;
    }

    #akhir-lata{
        color: var(--h-color);
        font-family: "Open Sans", Arial, sans-serif;
        font-size: 13px;
        font-weight: 500;
        line-height: 1.5em;
    }

    #akhir-p-id2{
        color: var(--h-color);
        font-family: "Open Sans", Arial, sans-serif;
        font-size: 13px;
        font-weight: 500;
        line-height: 1.5em;
    }

    #fh5co-footer{
        padding: 1em;
    }
    #link-foot{
        background-color: var(--h-color);
    }
    #nama_tamu{
        color: var(--primary-color) !important;
    }
    #ucapan_tamu{
        color: var(--primary-color) !important;
    }
    /* END Styling */

    #fh5co-header {
        position: relative;
        margin-bottom: 0;
        z-index: 9999999;
    }

    .stuck {
        position: fixed !important;
        top: 0 !important;
        -webkit-box-shadow: 0 2px 2px rgba(0, 0, 0, 0.05);
        -moz-box-shadow: 0 2px 2px rgba(0, 0, 0, 0.05);
        -ms-box-shadow: 0 2px 2px rgba(0, 0, 0, 0.05);
        -o-box-shadow: 0 2px 2px rgba(0, 0, 0, 0.05);
        box-shadow: 0 2px 2px rgba(0, 0, 0, 0.05);
    }

    .header-top {
        padding: 10px 0;
        background: #F69D9D;
    }

    .header-top .fh5co-link a {
        margin-left: 10px;
        font-size: 13px;
        color: rgba(255, 255, 255, 0.7);
    }

    .header-top .fh5co-link a:first-child {
        margin-left: 0;
    }

    .header-top .fh5co-link a:hover {
        color: white !important;
    }

    @media  screen and (max-width: 768px) {
        .header-top .fh5co-link {
            text-align: center;
        }
    }

    .header-top .fh5co-social a {
        color: rgba(255, 255, 255, 0.7);
        font-size: 14px;
        margin-right: 15px;
        position: relative;
        -webkit-transition: 0.5s, ease-in-out;
        -o-transition: 0.5s, ease-in-out;
        transition: 0.5s, ease-in-out;
    }

    .header-top .fh5co-social a:last-child {
        margin-right: 0;
    }

    .header-top .fh5co-social a:hover,
    .header-top .fh5co-social a:focus,
    .header-top .fh5co-social a:active {
        text-decoration: none;
        color: white !important;
    }

    .header-top .fh5co-social a:hover i,
    .header-top .fh5co-social a:focus i,
    .header-top .fh5co-social a:active i {
        -webkit-transform: scale(1.2);
        -moz-transform: scale(1.2);
        -ms-transform: scale(1.2);
        -o-transform: scale(1.2);
        transform: scale(1.2);
    }

    @media  screen and (max-width: 768px) {
        .header-top .fh5co-social {
            text-align: center !important;
        }
    }


    /* @media  screen and (max-width: 768px) {

        .fh5co-cover,
        .fh5co-hero {
            height: 700px;
        }
    } */

    .fh5co-overlay {
        position: absolute !important;
        width: 100%;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        z-index: 1;
        background: rgba(0, 0, 0, 0.4);
    }

    /* @media  screen and (max-width: 768px) {
        .fh5co-cover {
            heifght: inherit;
            padding: 3em 0;
        }
    } */

    @media  screen and (max-width: 768px) {
        .fh5co-cover .display-t {
            height: 600px;
        }
    }

    .fh5co-cover .display-tc h2 {
        color: #fff;
        font-size: 80px;
        margin-bottom: 30px;
        font-weight: 300 !important;
    }

    .fh5co-cover .display-tc h2 strong {
        font-weight: 700;
    }

    @media  screen and (max-width: 768px) {
        .fh5co-cover .display-tc h2 {
            font-size: 60px;
        }
    }

    .fh5co-cover .display-tc p {
        color: #fff;
        font-weight: 400;
        font-size: 16px;
        letter-spacing: 7px;
    }



    /* Superfish Override Menu */
    .sf-menu {
        margin: 7px 0 0 0 !important;
    }

    .sf-menu {
        float: right;
    }

    .sf-menu ul {
        box-shadow: none;
        border: transparent;
        min-width: 12em;
        
    }

    .sf-menu a {
        color: rgba(0, 0, 0, 0.5);
        padding: 0.75em 1em !important;
        font-weight: normal;
        border-left: none;
        border-top: none;
        border-top: none;
        text-decoration: none;
        zoom: 1;
        font-size: 16px;
        border-bottom: none !important;
    }

    .sf-menu a:hover,
    .sf-menu a:focus {
        color: #F69D9D !important;
    }

    .sf-menu li.active a:hover,
    .sf-menu li.active a:focus {
        color: #F69D9D;
    }

    .sf-menu li,
    .sf-menu ul li,
    .sf-menu ul ul li,
    .sf-menu li:hover,
    .sf-menu li.sfHover {
        background: transparent;
    }

    .sf-menu ul li a,
    .sf-menu ul ul li a {
        text-transform: none;
        padding: 0.2em 1em !important;
        letter-spacing: 1px;
        font-size: 14px !important;
    }

    .sf-menu li:hover a,
    .sf-menu li.sfHover a,
    .sf-menu ul li:hover a,
    .sf-menu ul li.sfHover a,
    .sf-menu li.active a {
        color: #F69D9D;
    }

    .sf-menu ul li:hover,
    .sf-menu ul li.sfHover {
        background: transparent;
    }

    .sf-menu ul li {
        background: transparent;
    }

    .sf-arrows .sf-with-ul {
        padding-right: 2.5em;
        
    }

    .sf-arrows .sf-with-ul:after {
        content: '';
        position: absolute;
        top: 50%;
        right: 1em;
        margin-top: -3px;
        height: 0;
        width: 0;
        border: 5px solid transparent;
        border-top-color: #ccc;
    }

    .sf-arrows>li>.sf-with-ul:focus:after,
    .sf-arrows>li:hover>.sf-with-ul:after,
    .sf-arrows>.sfHover>.sf-with-ul:after {
        border-top-color: #ccc;
    }

    .sf-arrows ul .sf-with-ul:after {
        margin-top: -5px;
        margin-right: -3px;
        border-color: transparent;
        border-left-color: #ccc;
    }

    .sf-arrows ul li>.sf-with-ul:focus:after,
    .sf-arrows ul li:hover>.sf-with-ul:after,
    .sf-arrows ul .sfHover>.sf-with-ul:after {
        border-left-color: #ccc;
    }

    #fh5co-header-section {
        padding: 0;
        position: relative;
        left: 0;
        width: 100%;
        z-index: 1022;
        background: #fff;
    }

    .nav-header {
        position: relative;
        float: left;
        width: 100%;
    }

    #fh5co-logo {
        position: relative;
        z-index: 2;
        font-size: 30px;
        margin-top: 35px;
        font-weight: 700;
        float: left;
    }

    #fh5co-logo span {
        font-weight: 700;
    }

    @media  screen and (max-width: 768px) {
        #fh5co-logo {
            width: 100%;
            float: none;
            text-align: center;
        }
    }

    #fh5co-logo a {
        color: #F69D9D;
    }

    #fh5co-logo a:hover,
    #fh5co-logo a:focus {
        color: #F69D9D !important;
    }

    #fh5co-menu-wrap {
        position: relative;
        z-index: 2;
        display: block;
        float: right;
        margin-top: 15px;
    }

    #fh5co-menu-wrap .sf-menu a {
        padding: 1em .75em;
    }

    #fh5co-primary-menu>li>ul li.active>a {
        color: #F69D9D !important;
    }

    #fh5co-primary-menu>li>.sf-with-ul:after {
        border: none !important;
        font-family: 'icomoon';
        speak: none;
        font-style: normal;
        font-weight: normal;
        font-variant: normal;
        text-transform: none;
        line-height: 1;
        /* Better Font Rendering =========== */
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        position: absolute;
        float: right;
        margin-right: -0px;
        top: 50%;
        font-size: 12px;
        margin-top: -7px;
        content: "\e922";
        color: rgba(0, 0, 0, 0.5);
    }

    #fh5co-primary-menu>li>ul li {
        position: relative;
    }

    #fh5co-primary-menu>li>ul li>.sf-with-ul:after {
        border: none !important;
        font-family: 'icomoon';
        speak: none;
        font-style: normal;
        font-weight: normal;
        font-variant: normal;
        text-transform: none;
        line-height: 1;
        /* Better Font Rendering =========== */
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        position: absolute;
        float: right;
        margin-right: 10px;
        top: 20px;
        font-size: 12px;
        content: "\e924";
        color: rgba(0, 0, 0, 0.5);
    }

    #fh5co-primary-menu .fh5co-sub-menu {
        padding: 10px 7px 10px;
        background: #fff;
        left: 0;
        -webkit-border-radius: 5px;
        -moz-border-radius: 5px;
        -ms-border-radius: 5px;
        border-radius: 5px;
        -webkit-box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
        -moz-box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
        -ms-box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
        -o-box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
    }

    #fh5co-primary-menu .fh5co-sub-menu>li>.fh5co-sub-menu {
        left: 100%;
    }

    #fh5co-primary-menu .fh5co-sub-menu:before {
        position: absolute;
        top: -9px;
        left: 20px;
        width: 0;
        height: 0;
        content: '';
    }

    #fh5co-primary-menu .fh5co-sub-menu:after {
        position: absolute;
        top: -8px;
        left: 21px;
        width: 0;
        height: 0;
        border-right: 8px solid transparent;
        border-bottom: 8px solid #fff;
        border-bottom: 8px solid white;
        border-left: 8px solid transparent;
        content: '';
    }

    #fh5co-primary-menu .fh5co-sub-menu .fh5co-sub-menu:before {
        top: 6px;
        left: 100%;
    }

    #fh5co-primary-menu .fh5co-sub-menu .fh5co-sub-menu:after {
        top: 7px;
        right: 100%;
        border: none !important;
    }

    .site-header.has-image #primary-menu .sub-menu {
        border-color: #ebebeb;
        -webkit-box-shadow: 0 5px 15px 4px rgba(0, 0, 0, 0.09);
        -moz-box-shadow: 0 5px 15px 4px rgba(0, 0, 0, 0.09);
        -ms-box-shadow: 0 5px 15px 4px rgba(0, 0, 0, 0.09);
        -o-box-shadow: 0 5px 15px 4px rgba(0, 0, 0, 0.09);
        box-shadow: 0 5px 15px 4px rgba(0, 0, 0, 0.09);
    }
    form#urutan-komponen-form p {
        color: black;
    }
    .site-header.has-image #primary-menu .sub-menu:before {
        display: none;
    }

    #fh5co-primary-menu .fh5co-sub-menu a {
        letter-spacing: 0;
        padding: 0 15px;
        font-size: 18px;
        line-height: 34px;
        color: #575757 !important;
        text-transform: none;
        background: none;
    }

    #fh5co-primary-menu .fh5co-sub-menu a:hover {
        color: #F69D9D !important;
    }

    #fh5co-countdown,
    #fh5co-groom-bride,
    #fh5co-blog-section,
    #fh5co-started,
    #fh5co-guest,
    .fh5co-content-section {
        padding: 7em 0;
    }

    @media  screen and (max-width: 768px) {

        #fh5co-couple,
        #fh5co-countdown,
        #fh5co-groom-bride,
        #fh5co-blog-section,
        #fh5co-started,
        #fh5co-when-where,
        #fh5co-guest,
        #fh5co-gallery,
        .fh5co-content-section {
            padding: 4em 0;
        }
    }

    .heading-section {
        padding-bottom: 1em;
        margin-bottom: 3em;
    }

    .heading-section h2 {
        font-size: 50px;
        font-weight: 300;
        position: relative;
        color: #F69D9D;
    }

    .heading-section p {
        font-size: 18px;
    }

    #fh5co-couple img {
        margin-bottom: 20px;
        -webkit-border-radius: 50%;
        -moz-border-radius: 50%;
        -ms-border-radius: 50%;
        border-radius: 50%;
    }

    #fh5co-couple h3 {
        font-size: 30px;
    }

    @media  screen and (max-width: 768px) {
        #fh5co-couple h3 {
            font-size: 35px;
        }
    }

    #fh5co-couple .amp-center {
        font-size: 60px;
        margin-top: 100%;
        color: #f69d9d;
    }

    @media  screen and (max-width: 768px) {
        #fh5co-couple .amp-center {
            font-size: 40px;
        }
    }

    #fh5co-countdown {
        background: #F69D9D;
    }

    #fh5co-countdown .countdown {
        margin-bottom: 0;
        font-size: 80px;
        color: #fff;
    }

    #fh5co-countdown .countdown span {
        margin: 0 30px;
        display: inline-block;
        font-family: "Montez", cursive;
    }

    #fh5co-countdown .countdown small {
        display: block;
        font-size: 16px;
        font-family: "Open Sans", Arial, sans-serif;
    }

    .couple-wrap {
        width: 100%;
        float: left;
        background: #F6FAF7;
    }

    .couple-desc {
        padding: 3em;
    }

    @media  screen and (max-width: 768px) {
        .couple-desc {
            padding: 1.5em;
        }
    }

    .couple-desc h3 {
        font-size: 40px;
    }

    .couple-desc .fh5co-social-icons a:first-child {
        padding-left: 0;
    }

    @media  screen and (max-width: 768px) {
        .couple-desc .fh5co-social-icons a i {
            font-size: 20px;
        }
    }

    .wedding-events {
        background: #fff;
    }

    .wedding-events .ceremony-bg {
        background-size: cover;
        background-position: center center;
        background-repeat: no-repeat;
        position: relative;
        height: 400px;
    }

    .wedding-events .desc {
        padding: 2em;
    }

    .wedding-events .desc h3 {
        font-size: 30px;
    }

    .wedding-events .desc p strong {
        font-size: 14px;
    }

    #fh5co-started {
        position: relative;
        background-size: cover;
        background-position: bottom center;
        background-repeat: no-repeat;
    }

    #fh5co-started .overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
    }

    #fh5co-started .form-control {
        background: rgba(0, 0, 0, 0.2);
        border: none !important;
        color: #fff;
        font-size: 16px !important;
        width: 100%;
        -webkit-transition: 0.5s;
        -o-transition: 0.5s;
        transition: 0.5s;
    }

    #fh5co-started .form-control::-webkit-input-placeholder {
        color: #fff;
    }

    #fh5co-started .form-control:-moz-placeholder {
        /* Firefox 18- */
        color: #fff;
    }

    #fh5co-started .form-control::-moz-placeholder {
        /* Firefox 19+ */
        color: #fff;
    }

    #fh5co-started .form-control:-ms-input-placeholder {
        color: #fff;
    }

    #fh5co-started .form-control:focus {
        background: rgba(255, 255, 255, 0.3);
    }

    #fh5co-started .btn-block {
        height: 54px;
        border: none !important;
        background: #F69D9D;
        color: #fff;
        font-size: 16px;
        text-transform: uppercase;
        font-weight: 400;
        padding-left: 50px;
        padding-right: 50px;
    }

    #fh5co-started .form-inline .form-group {
        width: 100% !important;
        margin-bottom: 10px;
    }

    #fh5co-started .form-inline .form-group .form-control {
        width: 100%;
        padding: 27px 20px !important;
    }

    #fh5co-started .heading-section {
        margin-bottom: 30px;
    }

    #fh5co-started .heading-section h2 {
        margin-bottom: 20px;
        color: rgba(255, 255, 255, 0.9);
    }

    #fh5co-started .heading-section p {
        color: rgba(255, 255, 255, 0.7);
    }

    .groom-men img {
        margin-bottom: 20px;
        -webkit-border-radius: 50%;
        -moz-border-radius: 50%;
        -ms-border-radius: 50%;
        border-radius: 50%;
    }

    .groom-men h3 {
        font-family: "Open Sans", Arial, sans-serif;
        font-size: 18px;
    }

    .gallery {
        margin-bottom: 30px;
    }

    .gallery .gallery-img {
        width: 100%;
        float: left;
        overflow: hidden;
        position: relative;
        z-index: 1;
        margin-bottom: 25px;
    }

    .gallery .gallery-img img {
        position: relative;
        max-width: 100%;
        -webkit-transform: scale(1);
        -moz-transform: scale(1);
        -ms-transform: scale(1);
        -o-transform: scale(1);
        transform: scale(1);
        -webkit-transition: 0.9s;
        -o-transition: 0.9s;
        transition: 0.9s;
    }

    .gallery .gallery-img:hover img {
        -webkit-transform: scale(1.1);
        -moz-transform: scale(1.1);
        -ms-transform: scale(1.1);
        -o-transform: scale(1.1);
        transform: scale(1.1);
    }

    .fh5co-blog {
        margin-bottom: 60px;
    }

    .fh5co-blog a img {
        width: 100%;
    }

    @media  screen and (max-width: 768px) {
        .fh5co-blog {
            width: 100%;
        }
    }

    .fh5co-blog .blog-text {
        margin-bottom: 30px;
        position: relative;
        background: #fff;
        width: 100%;
        padding: 30px;
        float: right;
    }

    .fh5co-blog .blog-text span {
        display: inline-block;
        margin-bottom: 20px;
        font-size: 18px;
    }

    .fh5co-blog .blog-text span.by {
        color: rgba(0, 0, 0, 0.5);
        margin-right: 7px;
    }

    .fh5co-blog .blog-text span.posted_date {
        color: rgba(0, 0, 0, 0.5);
        margin-right: 7px;
    }

    .fh5co-blog .blog-text span.comment a {
        color: rgba(0, 0, 0, 0.3);
    }

    .fh5co-blog .blog-text span.comment a i {
        color: #F69D9D;
        padding-left: 4px;
    }

    .fh5co-blog .blog-text h3 {
        font-size: 20px;
        margin-bottom: 20px;
        font-weight: 300;
        line-height: 1.5;
        font-family: "Open Sans", Arial, sans-serif;
    }

    .fh5co-blog .blog-text h3 a {
        color: rgba(0, 0, 0, 0.6);
    }

    #map {
        width: 100%;
        height: 500px;
        position: relative;
    }

    @media  screen and (max-width: 768px) {
        #map {
            height: 200px;
        }
    }

    .fh5co-social-icons>a {
        padding: 4px 10px;
        color: #F69D9D;
    }

    .fh5co-social-icons>a i {
        font-size: 26px;
    }

    .fh5co-social-icons>a:hover,
    .fh5co-social-icons>a:focus,
    .fh5co-social-icons>a:active {
        text-decoration: none;
        color: #5a5a5a;
    }

    #footer {
        background: #F69D9D;
        padding: 60px 0 40px;
    }

    #footer p {
        color: white;
        font-size: 14px;
    }

    #footer p a {
        color: rgba(255, 255, 255, 0.5);
    }

    #footer p a:hover,
    #footer p a:active,
    #footer p a:focus {
        color: rgba(255, 255, 255, 0.9) !important;
    }

    #footer h2 {
        color: #fff;
        font-size: 60px;
    }

    .btn {
        text-transform: uppercase;
        letter-spacing: 2px;
        -webkit-transition: 0.3s;
        -o-transition: 0.3s;
        transition: 0.3s;
    }

    .btn.btn-default:hover,
    .btn.btn-default:focus,
    .btn.btn-default:active {
        border-color: transparent;
    }

    .js .animate-box {
        opacity: 0;
    }

    #fh5co-wrapper {
        overflow-x: hidden;
        position: relative;
    }

    .fh5co-offcanvas {
        overflow: hidden;
    }

    .fh5co-offcanvas #fh5co-wrapper {
        overflow: hidden !important;
    }

    #fh5co-page {
        position: relative;
        -webkit-transition: 0.5s;
        -o-transition: 0.5s;
        transition: 0.5s;
    }

    .fh5co-offcanvas #fh5co-page {
        -moz-transform: translateX(-240px);
        -webkit-transform: translateX(-240px);
        -ms-transform: translateX(-240px);
        -o-transform: translateX(-240px);
        transform: translateX(-240px);
    }

    @media  screen and (max-width: 768px) {
        #fh5co-menu-wrap {
            display: none;
        }
    }

    #offcanvas-menu {
        position: fixed;
        top: 0;
        bottom: 0;
        z-index: 99;
        background: #222;
        right: -240px;
        width: 240px;
        padding: 20px;
        /* overflow-y: scroll !important; */
        display: none;
    }

    @media  screen and (max-width: 768px) {
        #offcanvas-menu {
            display: block;
        }
    }

    #offcanvas-menu ul {
        padding: 0;
        margin: 0;
    }

    #offcanvas-menu ul li {
        padding: 0;
        margin: 0 0 10px 0;
        list-style: none;
    }

    #offcanvas-menu ul li a {
        font-size: 18px;
        color: rgba(255, 255, 255, 0.4);
    }

    #offcanvas-menu ul li a:hover {
        color: #F69D9D;
    }

    #offcanvas-menu ul li>.fh5co-sub-menu {
        margin-top: 9px;
        padding-left: 20px;
    }

    #offcanvas-menu ul li.active>a {
        color: #F69D9D;
    }

    #offcanvas-menu ul .fh5co-sub-menu {
        display: block !important;
    }

    .fh5co-nav-toggle {
        cursor: pointer;
        text-decoration: none;
    }

    .fh5co-nav-toggle.active i::before,
    .fh5co-nav-toggle.active i::after {
        background: #fff;
    }

    .fh5co-nav-toggle.dark.active i::before,
    .fh5co-nav-toggle.dark.active i::after {
        background: #fff;
    }

    .fh5co-nav-toggle:hover,
    .fh5co-nav-toggle:focus,
    .fh5co-nav-toggle:active {
        outline: none;
        border-bottom: none !important;
    }

    .fh5co-nav-toggle i {
        position: relative;
        display: -moz-inline-stack;
        display: inline-block;
        zoom: 1;
        width: 30px;
        height: 2px;
        color: #fff;
        font: bold 14px/.4 Helvetica;
        text-transform: uppercase;
        text-indent: -55px;
        background: #fff;
        transition: all .2s ease-out;
    }

    .fh5co-nav-toggle i::before,
    .fh5co-nav-toggle i::after {
        content: '';
        width: 30px;
        height: 2px;
        background: #fff;
        position: absolute;
        left: 0;
        -webkit-transition: 0.2s;
        -o-transition: 0.2s;
        transition: 0.2s;
    }

    .fh5co-nav-toggle.dark i {
        position: relative;
        color: #000;
        background: #000;
        transition: all .2s ease-out;
    }

    .fh5co-nav-toggle.dark i::before,
    .fh5co-nav-toggle.dark i::after {
        background: #000;
        -webkit-transition: 0.2s;
        -o-transition: 0.2s;
        transition: 0.2s;
    }

    .fh5co-nav-toggle i::before {
        top: -7px;
    }

    .fh5co-nav-toggle i::after {
        bottom: -7px;
    }

    .fh5co-nav-toggle:hover i::before {
        top: -10px;
    }

    .fh5co-nav-toggle:hover i::after {
        bottom: -10px;
    }

    .fh5co-nav-toggle.active i {
        background: transparent;
    }

    .fh5co-nav-toggle.active i::before {
        top: 0;
        -webkit-transform: rotateZ(45deg);
        -moz-transform: rotateZ(45deg);
        -ms-transform: rotateZ(45deg);
        -o-transform: rotateZ(45deg);
        transform: rotateZ(45deg);
    }

    .fh5co-nav-toggle.active i::after {
        bottom: 0;
        -webkit-transform: rotateZ(-45deg);
        -moz-transform: rotateZ(-45deg);
        -ms-transform: rotateZ(-45deg);
        -o-transform: rotateZ(-45deg);
        transform: rotateZ(-45deg);
    }

    .fh5co-nav-toggle {
        position: absolute;
        top: 0px;
        right: 0px;
        z-index: 9999;
        display: block;
        margin: 0 auto;
        display: none;
        cursor: pointer;
    }

    @media  screen and (max-width: 768px) {
        .fh5co-nav-toggle {
            display: block;
            top: 0px;
            margin-top: 2em;
        }
    }

    @media  screen and (max-width: 480px) {
        .col-xxs-12 {
            float: none;
            width: 100%;
        }
    }

    .row-bottom-padded-lg {
        padding-bottom: 7em;
    }

    @media  screen and (max-width: 768px) {
        .row-bottom-padded-lg {
            padding-bottom: 2em;
        }
    }

    .row-top-padded-lg {
        padding-top: 7em;
    }

    @media  screen and (max-width: 768px) {
        .row-top-padded-lg {
            padding-top: 2em;
        }
    }
    .row-top-padded-md {
        padding-top: 4em;
    }

    @media  screen and (max-width: 768px) {
        .row-top-padded-md {
            padding-top: 2em;
        }
    }

    .row-bottom-padded-sm {
        padding-bottom: 2em;
    }

    @media  screen and (max-width: 768px) {
        .row-bottom-padded-sm {
            padding-bottom: 2em;
        }
    }

    .row-top-padded-sm {
        padding-top: 2em;
    }

    @media  screen and (max-width: 768px) {
        .row-top-padded-sm {
            padding-top: 2em;
        }
    }

    .nopadding {
        padding: 0 !important;
        margin: 0 !important;
    }

    .padding {
        padding-left: 15px !important;
        padding-right: 15px !important;
    }

    .border-bottom {
        border-bottom: 1px solid rgba(0, 0, 0, 0.06);
    }

    .lead {
        line-height: 1.8;
    }

    .no-js #loader {
        display: none;
    }

    .js #loader {
        display: block;
        position: absolute;
        left: 100px;
        top: 0;
    }

    .fh5co-loader {
        position: fixed;
        left: 0px;
        top: 0px;
        width: 100%;
        height: 100%;
        z-index: 9999;
        background: url(../images/hourglass.svg) center no-repeat #222222;
    }

    #c-profile-id .circle{
        border: 4px solid #e5a118 !important;
    }

    .btn-profile-acara-default{
        position: relative; display: flex; margin: 0 auto; color: #000000 !important;
            justify-content: center; background: #fff !important; align-content: center; align-items: center; width: fit-content; padding: 5px 10px;
            border-radius: 5px; font-size: 12px; margin-top: 10px;
    }
    .btn-profile-acara-default svg path{
        fill: #000000 !important;
    }
</style>
    
    <style>
    html, body {
        overflow-x: hidden;
    }

    img {
        pointer-events: none;
    }
    

    .form-label {
        font-size: 12px !important;
    }


    .box-shadow-new {
        filter: drop-shadow(2px 2px 4px rgba(0, 0, 0, 0.5));
    }

    @import  url("https://fonts.googleapis.com/css2?family=Joan&display=swap");

    .svg-loading {
        font-family: "Joan", sans-serif;
        width: 100%; height: 100%;
    }
    .svg-loading text {
        animation: stroke 3s infinite alternate;
        stroke-width: 0;
        stroke: #009cd9;
        font-size: 35px;
    }
    @keyframes  stroke {
        0%   {
            fill: rgba(72,138,204,0); stroke: rgba(54,95,160,1);
            stroke-dashoffset: 25%; stroke-dasharray: 0 50%; stroke-width: 1;
        }
        70%  {fill: rgba(72,138,204,0); stroke: rgba(54,95,160,1); }
        80%  {fill: rgba(72,138,204,0); stroke: rgba(54,95,160,1); stroke-width: 1.5; }
        100% {
            fill: rgba(72,138,204,1); stroke: rgba(54,95,160,0);
            stroke-dashoffset: -25%; stroke-dasharray: 50% 0; stroke-width: 0;
        }
    }

    .selected-tab {
        border-bottom: 3px solid #4299e1 !important;
        color: #1d1d1d !important;
    }

    .edit-modal-body p {
        color: #222222 !important;
    }

    .elemen-tambah-edit {
        margin: 20px 0px;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100px;
        flex-direction: column;
    }

    .elemen-tambah-edit-text {
        display: flex;
        font-size: 12px;
        color: #aaaaaa;
        font-style: italic;
    }

    .elemen-tambah-edit-svg {
        margin-top: 3px;
        margin-right: 5px;
    }

    @media (min-width: 768px) {
      .fix-menu {
        max-width: 400px !important;
      }
    }
    .m_scroll_arrows {
        display: block;
        width: 5px;
        height: 5px;
        transform: rotate(45deg);
        border-right: 2px solid  #e5a118 ;
        border-bottom: 2px solid  #e5a118 ;
        margin: 0 0 3px 4px;
        width: 15px;
        height: 15px;
    }
</style>

</head>

<body style="position:relative">
    <!-- MODAL BANTU BAYAR -->
<!-- END MODAL BANTU BAYAR -->
    <div id="fun-div-id1" class="mob-con">
        <div class="overlay-page"></div>
        <div class="overlay-tutor-realtime" id="overlay-tutor-realtime"></div>
<div id="kucing_imut" style="display: table; height: 100vh;background-color: #fffffff2;position: fixed;z-index: 99999999;width: 100vw;">
    <div class="middle" style="display: table-cell; vertical-align: middle;">
        <div class="inner" style="margin-left: auto;margin-right: auto;width: 400px; text-align: center">
                                                        <div class="loader"></div>

        <style>
        .loader {
        border: 8px solid #f3f3f3; /* Background abu */
        border-top: 8px solid #555; /* Warna animasi */
        border-radius: 50%;
        width: 50px;
        height: 50px;
        animation: spin 1s linear infinite;
        margin: 0 auto;
        }
        @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
        }
        </style>
                <div style="height: 50px"></div>
                
        <p style="font-size: 12px; color:#000; padding: 0px 40px; margin-top: -50px; line-height: 14px;">Untuk tampilan terbaik gunakan Google Chrome dan matikan mode gelap</p>
            
        </div>
    </div>
</div>

<div id="template-ucapan-all"></div>





<!-- hapus -->
        



<script>
  document.addEventListener("DOMContentLoaded", () => {
    const checkbox = document.getElementById("ongkir_ditanggung_penerima");
    const elements = document.querySelectorAll(".ongkir-receiver-off");
    const toggleDisplay = () => {
      elements.forEach(el => el.style.display = checkbox.checked ? "none" : "flex")
      $('.total-kado-id').text(rupiah(totalKado));
      if(!$('#ongkir_ditanggung_penerima').is(':checked')){
        const ongkir = 45000
        const diskon = 20000
        $('.total-kado-id').text(rupiah(totalKado+ongkir-diskon));
      }
    }
    checkbox.addEventListener("change", toggleDisplay);
    toggleDisplay();
  });
</script>

<!-- hapus -->
        <div id="fun-div-id2" class="awal">
            <div id="welcomescreennew" class="welcome-in">
                <div class="modal-backdrop"
                    style="background-color: #000000; opacity: 0.6; vertical-align: central; text-align: center">
                </div>
                <div style="width: 100%; height: 100vh; text-align: center; position: fixed; z-index: 2000;">
                    <div style="position: absolute; z-index:10; height:100%; width:100%;margin-top:270px;">
                        <h1 id="awal-h1-id1" style="color: #fff; font-size: 25px;" data-aos="fade-up">We Invite You To</h1>
                                                <div class="nama_acara_cli">
        <h1 id="aca-fun-h1-id12" class="nama_acara_gr acara-eg" data-aos="fade-down">Pernikahan <br> Ali Sandi, S.P & Ays, S.Pd</h1>
    </div>
 
        
                                                <br>
                        <label class="textKepada" data-aos="fade-up">
                            Kepada Yth.
                        </label>
                        <br>
                        <div class="divKepada" data-aos="fade-up">
                            <span  style="font-weight: 400;"> Keluarga Besar Indomaret Labota 44 </span>
                        </div>
                        <br>
                        <label class="textKepada" style="font-size: 15px;
                        font-weight: 400;
                        font-family: 'Open Sans';
                        width: 90%;" data-aos="fade-up">
                            Tanpa Mengurangi Rasa Hormat, Kami Mengundang Bapak/Ibu/Saudara/i untuk Hadir di Acara Kami.
                        </label>

                        <div style="margin-top:5px;">
                            <a class="btn btn-primary" role="button" >
                                Buka Undangan
                            </a>
                        </div>
                    </div>
                                        <img id="ImageWelcomeInvitation"
                        src="./img2/18.jpeg"
                        style="border-width:0px;width:100%; height:100vh; object-fit: cover;">
                    <div
                        style="background: rgb(0 0 0 / 55%);; width:100%; height:100%; position:absolute; left: 0; top: 0;">
                    </div>
                </div>
            </div>
        </div>

        <div id="fun-div-id6" class="fh5co-loader"></div>

        <div id="page">
                        
                                    <div id="fun-div-id8" class="box-1">
                <div class="overlayy"></div>
                                <div id="fun-div-id9" class="">
                    <div id="background-box-1">
                        <div id="overlay-box-1" class="fh5co-overlay"></div>
                        <div class="fh5co-cover text-center">
                            <div class="display-t">
                                <div data-aos="fade-up">
                                                                        <div id="c-nama-acara-id" class="nama_acara_cli">
<div style="height: 20px"></div>
        <h1 class="nama_acara_cli nama_acara_gr acara-eg judul" id="nm-acara-fun-h1-id3"  data-aos="zoom-in">Wedding <br> Ali Sandi, S.P & Ays, S.Pd</h1>

</div>



                                                                        
                                                                        <div class="scroll-icon">
                                        <div class="mouse_scroll" data-anim="fade-down" data-anim-delay="1500"
                                            onclick="scrollToBox2()">
                                            <div>
                                                <span class="m_scroll_arrows unu"></span>
                                                <span class="m_scroll_arrows doi"></span>
                                                <span class="m_scroll_arrows trei"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                        

        
                        <div id="fh5co-couple" class="box-2 text-center fh5co-section-gray"
            style="padding-bottom: 0px; background-color: black;">
                        <div class="container">
                <div class="row">
                    <div class="col-md-12">
                                                
                                                
                                                <div id="fun-div-id22" data-aos="zoom-in" class="black-box ucapan_pembuka_cli ucapan_pembuka_gr">
      <div id="c-ucapan-pembuka-id">Atas Berkah dan Rahmat Allah Subhanallahu Wa Ta'ala. Tanpa mengurangi rasa hormat. Kami mengundang Bapak/Ibu/Saudara/i serta kerabat sekalian untuk menghadiri acara pernikahan kami :</div>
    </div>

  






                                                <div class="c-sampul-id foto_sampul_cli">
    
        <div id="awal-img-fun-div-id23" data-aos="zoom-in" class=" sampul-eg"
    style="display: block; margin: 0 auto; margin-bottom: 10px; margin-top: 20px; width: 200px; height: 200px; border-radius: 200px; overflow: hidden; background:url('./img2/9.jpeg'); background-position: center; background-repeat: no-repeat; background-size: cover;">
</div> 
        </div>
                                                <div style="height: 20px"></div>
<div id="c-data-pria-id">


        <div class="row">
    <div class="col-md-12">
        <div class="data_pria_cli">
            <h1 data-aos="fade-up"
                style="text-transform: capitalize; font-size: 40px; margin-top: 20px; color:#e5a118; margin-bottom: 10px;">
                <strong><em>Ali Sandi, S.P</em></strong>
        </h1>
            
            <div style='text-transform: capitalize; font-family: "Open Sans", Arial, sans-serif; font-size: 14px; color:white'
                data-aos="fade-up">
              <p class="dataMep" id="pria-fun-anak-ke">Anak dari Pasangan</span></p>
  <p class="dataMep" id="pria-fun-ayah">Bapak La Sanudi(Alm) &</p>
  <p class="dataMep" id="pria-fun-ibu">Ibu Wati(Alm)</p>
  <p style="margin-bottom: 20px;" id="pria-fun-alamat">
  Beralamat di Kelurahan gonda baru, <br> Lingk. Amanasi Rw.01 Rt.03</p>

            </div>
                    </div>
       
    </div>
</div>
        <div class="h-16"></div>
    </div>




<div class="love">
    <h2 data-aos="fade-up" id="sparator">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path fill="#FFD43B" d="M442.9 144C415.6 144 389.9 157.1 373.9 179.2L339.5 226.8C335 233 327.8 236.7 320.1 236.7C312.4 236.7 305.2 233 300.7 226.8L266.3 179.2C250.3 157.1 224.6 144 197.3 144C150.3 144 112.2 182.1 112.2 229.1C112.2 279 144.2 327.5 180.3 371.4C221.4 421.4 271.7 465.4 306.2 491.7C309.4 494.1 314.1 495.9 320.2 495.9C326.3 495.9 331 494.1 334.2 491.7C368.7 465.4 419 421.3 460.1 371.4C496.3 327.5 528.2 279 528.2 229.1C528.2 182.1 490.1 144 443.1 144zM335 151.1C360 116.5 400.2 96 442.9 96C516.4 96 576 155.6 576 229.1C576 297.7 533.1 358 496.9 401.9C452.8 455.5 399.6 502 363.1 529.8C350.8 539.2 335.6 543.9 320 543.9C304.4 543.9 289.2 539.2 276.9 529.8C240.4 502 187.2 455.5 143.1 402C106.9 358.1 64 297.7 64 229.1C64 155.6 123.6 96 197.1 96C239.8 96 280 116.5 305 151.1L320 171.8L335 151.1z"/></svg>
</h2>
</div>


 
<style>
    #sparator {
  margin-top: 10%;
  margin-bottom: 10%;
  color:#e5a118;
  text-align: center; 
  justify-content: center;
  margin-left: 45%;
   /* center untuk isi */
}

#sparator svg {
  width: 50px;
  height: 50px;
}



</style>

                                                <div style="height: 20px"></div>
<div id="c-data-wanita-id">


        
<div class="row">
    <div class="col-md-12">
        <div class="data_wanita_cli">
            <h1 data-aos="fade-up"
                style="text-transform: capitalize; font-size: 40px; margin-top: 20px; color:#e5a118; margin-bottom: 10px;">
                <strong><em>Ays, S.Pd</em></strong>
        </h1>
            
            <div data-aos="fade-up">
              <p class="dataMep" id="wanita-fun-anak-ke">Anak dari Pasangan</span></p>
  <p class="dataMep" id="wanita-fun-ayah">Bapak Arifin (Alm)</p>
  <p class="dataMep" id="wanita-fun-ibu">Ibu  Musrifa M.</p>
  <p class="dataMep" id="wanita-fun-alamat"> Beralamat Kel.Karyabaru, <br> lingkungan Hanura, RT 001 RW 002</p>
            </div>
                    </div>
    </div>
</div>
        </div>






                                                
                                            </div>
                </div>

            </div>
        </div>
                        

        
                        <div id="fun-div-id40" class="box-3 text-center hide-ucapan" style="position: relative;">
                        <div id="fun-div-id41" class="display-t">
                <div id="fun-div-id42" class="display-tc fadeInUp animated-fast">
                    
                    <div id="fun-div-id40" style="width: 90%; margin: 0 auto !important;border-radius: 5px;">
                        <div class="row bgPattern">
                            <div class="col-sm-12 text-center">
                                                                <div id="invisible-box" style="height: 20px"></div>
<div id="c-acara-id" class="map_id2 acara_detail">
        <div class="c_acara1 data_acara_cli">
    
    <div class="container">
        <h1 id="savedate-fun-h1-id1" class="c-acara-nm fun-h1-4 aos-init aos-animate" data-aos="zoom-in-down"> Save The Date</h4>
            </h1>
        <div style="padding:20px; border:solid 2px #ddd; margin-bottom:20px; background-color:black; border-radius:10%">
            <h1 style="color:#e5a118; font-size: 30px;">
              Selasa, 03 Januari 2026
            </h1>
            <h2 id="acara1-fun-h1-id1" class="ac_h1_eg" data-aos="fade-up"></h2>
                        <p class="custom_time1" style="color:white; text-transform: capitalize;">
                <em>
                    <b>12 : 30 WITA Sampai Selesai</b>
                    <br> Karyabaru
                </em>
            </p>
                                    <a class="btn btn-primary " data-aos="fade-up" href="https://maps.app.goo.gl/hyqXucu8y1mfYQBc8" target="_blank">
                Map Lokasi Acara <i aria-hidden="true" class="fa fa-arrow-right"></i>
            </a>
                    </div>
    </div>
    



    
        

        </div>
    </div>







                                                                <div style="height: 10px"></div>

      <div id="c-ucapan-penutup-id" data-aos="zoom-in" class="section2 ucapan_penutup_cli ucapan_penutup_gr">
      Besar harapan kami jika Bapak/Ibu/Sahabat/Sdr/i berkenan hadir pada acara ini. Atas perhatiannya Terima kasih
    </div>
  




                                                                
                                                                <div id="c-nama-acara-id" class="nama_acara_cli">
<div style="height: 20px"></div>
        <h1 class="nama_acara_cli nama_acara_gr acara-eg judul" id="nm-acara-fun-h1-id3"  data-aos="zoom-in">Pernikahan Ali Sandi, S.P <br> & <br> Ays, S.Pd</h1>

</div>



                                                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
                        

        
                        <div id="fh5co-when-where" class="box-4 text-center">
                        <div id="fun-div-id50a" class="display-t">
                <div id="fun-div-id51a" class="display-tc fadeInUp animated-fast">
                    
                    <img src="https://myevent.id/master/images/ornament-leaf2.png" class="img-fluid"
                        style="width:160px; margin:0px auto" data-aos="zoom-in-up">
                    <div id="fun-div-id53a" class="container" style="margin-top: 30px;">
                        <div id="fun-div-id54a" class="row" data-aos="zoom-in-up">
                            <div class="col-md-12">
                                                                
                                                                <div style="height: 20px"></div>


<div class="countdown-acara" data-aos="fade-up">
<style>
    .simply-countdown>.simply-section {
        display: inline-block;
        width: 85px;
        height: 70px;
        margin: 0 4px;
        background: none;
        position: relative;
        animation: none;
    }

    .simply-amount {
        display: block;
        font-family: "Open Sans", Arial, sans-serif;
        font-size: 40px !important;
        text-align: center;
        color: #fff !important;
    }

    .simply-word {
        display: block;
        font-family: 'Caramel', cursive;
        font-size: 20px !important;
        text-align: center;
        color: #fff !important;
    }
</style>
<div data-aos="fade-up" id="htm-fun-div-id1" class="simply-countdown simply-countdown-one"></div>
</div>

                                                                
                                                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
                        


        
        <div id="fh5co-started1" class="box-5 text-center  hide-ucapan"
            style="background-image: url(https://myevent.id/master/images/btm.jpg);background-position: center right !important; background-size:cover;  ">
                                    <div id="fun-div-id50" class="display-t">
                                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <img src="https://myevent.id/master/images/ornament-leaf2.png" class="img img-responsive"
                                style="width:140px; margin:0px auto">
                                                        <div class="galery_cli" id="c-galery-id" style="width: 100%;">

          
              <div id="fh5co-gallery" class="fh5co-section-gray">
    <div class="container" id="galery_id">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <h2 id="our-gallery-id4" data-aos="fade-up">Our Gallery</h2>
                
            </div>
        </div>

      



        <div class="row row-bottom-padded-md">
            <div class="col-12">
                <ul id="fh5co-gallery-list">           
                                        <li class="one-third lazy-background" data-aos=fade-left data-bg="./img2/1.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="./img2/1.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>

                                        <li class="one-third lazy-background" data-aos=fade-right data-bg="img2/5.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/5.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>

                                        <li class="one-third lazy-background" data-aos=fade-left data-bg="img2/7.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/7.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>

                                        <li class="one-third lazy-background" data-aos=fade-right data-bg="img2/8.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/8.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>

                                        <li class="one-third lazy-background" data-aos=fade-left data-bg="img2/28.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/28.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>

                                        <li class="one-third lazy-background" data-aos=fade-right data-bg="img2/9.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/9.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>

                                        <li class="one-third lazy-background" data-aos=fade-left data-bg="img2/14.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/14.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>

                                        <li class="one-third lazy-background" data-aos=fade-right data-bg="img2/11.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/11.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>
                                        <li class="one-third lazy-background" data-aos=fade-right data-bg="img2/12.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/12.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>
                                        <li class="one-third lazy-background" data-aos=fade-right data-bg="img2/21.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/21.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>
                                        <li class="one-third lazy-background" data-aos=fade-right data-bg="img2/19.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/19.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>
                                        <li class="one-third lazy-background" data-aos=fade-right data-bg="img2/17.jpeg" style=" width: 100%;margin: 5px;">
                        <a                             href="img2/17.jpeg" class="image-popup"
                        >
                            <div class="case-studies-summary">
                            </div>
                        </a>
                    </li>

                                    </ul>
            </div>
        </div>
    </div>
</div>

      
          
    </div>


                                                    </div>
                    </div>
                </div>
            </div>
        </div>
                        

<div class="dukungan-section">
    <h1 class="doa">doa & dukungan</h1>
    <h2 class="dukungan-title">Dengan hormat, kami mengundang Bapak/Ibu untuk memberikan dukungan melalui nomor rekening berikut:</h2>
    <h3 class="dukungan-rekening">6495 3560 71</h3>
</div>
        

        
        <div class="box-6 text-center hide-ucapan">
                                    <div class="display-t">
                                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                                                        
                                                        <div id="c-kehadiran-id" class="ucapan kehadiran_cli" style="content: none !important;width: 100%;">
    <div class="form-ucapan" style="    margin-bottom: 100px;">

        <div class="fh5co-heading-c">

            <h2 data-aos="fade-up"style="text-align: center; margin-top: 30px" id="kehadiran_text" data-aos="fade-up">Kehadiran</h2>


        <p data-aos="fade-up"id="notifPopupFill" class="alert alert-success px-0 py-0 m-3" style="font-size: 12px; display: none; background-color: #feffce !important; color: #393939 !important;" data-aos="fade-up">Your attendance form has been successfully submitted. <br> <a class="underline cursor-pointer" onclick="resetKehadiran()">Reset</a></p>

<form id="push_ucapan" method="POST">
    <div class="form-group col-md-12">
        <label>Nama</label>
        <input maxlength="20" required name="nama" id="konfir_nama_2" class="form-control form-fun">
    </div>

    <div class="form-group col-md-12">
        <label>Ucapan</label>
        <textarea required name="ucapan" id="ucapan_2" class="form-control form-fun" style="height: 100px;"></textarea>
    </div>

<div class="form-group col-md-12 font-p" id="filed_kehadiran" style="background-color: transparan" data-aos="fade-up">
                    <label data-aos="fade-up"class="form-label hadir_hadir">Kehadiran</label>
                    <select data-aos="fade-up"required class="form-control form-fun" name="ket_hadir" id="hadir_id">
                        <option value="" selected>Option</option>
                        <option class="val_nohadir" value="0">Tidak Hadir</option>
                        <option class="val_hadir" value="1">Hadir</option>
                    </select>
                </div>



    <button type="submit" class="btn btn-primary">Kirim</button>
</form>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $("#push_ucapan").submit(function(e){
        e.preventDefault(); // cegah reload form

        $.ajax({
            type: "POST",
            url: "simpan_ucapan.php", 
            data: $(this).serialize(),
            success: function(response){
                // Tambahkan komentar baru ke atas box tanpa reload
                $("#box_ucapan").prepend(response);

                // Reset form
                $("#push_ucapan")[0].reset();
            },
            error: function(xhr, status, error){
                alert("Gagal mengirim ucapan: " + error);
            }
        });
    });
});
</script>



    </div>

    </div>

    <div style="display:block"></div>

      <div data-aos="fade-up"class="box-ucapan-wrapper">
<div class="box-ucapan font-p" id="box_ucapan" style="background-color: #fff; text-align: left" data-aos="fade-up">
    <?php
    include "koneksi.php"; 
    $result = mysqli_query($conn, "SELECT * FROM ucapan ORDER BY created_at DESC");

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div style='margin-bottom:10px; padding:10px; border-bottom:1px solid #eee'>";
        echo "<strong>" . htmlspecialchars($row['nama']) . "</strong><br>";
        echo "<p>" . nl2br(htmlspecialchars($row['ucapan'])) . "</p>";
        echo "<small>Keterangan: " . ($row['ket_hadir'] ? 'Hadir' : 'Tidak Hadir'). "</small>";
        echo "</div>";
    }
    ?>
</div>

    </div>
   </div>







                                                    </div>
                    </div>
                </div>
            </div>
        </div>
                        

        
        <div id="fun-div-id49" class="akhir text-center  hide-ucapan">

            <div id="fun-div-id50" class="display-t">

                <div id="fun-div-id51" class="display-tc fadeInUp animated-fast">
                    
                    <div id="fun-div-id53"
                        style=" width: 100%; margin: 0 auto !important;border-radius: 5px;padding-bottom: 50px;">
                        <div class="container" style="margin-top: 67px;">
                            <h1 id="akhir-h1-id1" data-aos="fade-up"><div class="nama_acara_cli">
        <h1 id="aca-fun-h1-id12" class="nama_acara_gr acara-eg" data-aos="fade-down">Pernikahan Ali Sandi, S.P & Ays, S.Pd</h1>
    </div>
 
        </h1>
                            <div data-aos="fade-up"><div id="akhir-kata1" class="footer_text_cli footer_text_gr footer_text" data-aos="fade-up">
            <p id="akhir-kata" class="hide-ucapan footer_text">Merupakan Suatu Kebahagiaan dan Kehormatan bagi Kami, Apabila Bapak/Ibu/Saudara/i, Berkenan Hadir di Acara kami</p>
    </div>
</div>
                            <footer id="fh5co-footer" role="contentinfo" data-aos="fade-up">
                                <div id="fun-div-id64">
   
                                    
                                    <div class="row copyright">
    <div class="col-md-12 text-center">
                        
            <div id="watermark-indo" class="watermark_footer_cli" style="padding: 50px 0 100px 0;flex-wrap:wrap;align-items:center;">
        <div class="watermark-detail">
                </div>
            </div>
        </p>
        <audio autoplay loop id="playAudio">
                                    <source src="./img2/music.mp3">
                        </audio>
                <audio autoplay  id="playAudioS">
                    </audio>

    </div>
</div>
                                </div>
                            </footer>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

                <style>
    .fix-menu svg{
        fill: black !important;
    }

    .menu-edit p {
        font-size: 10px !important;
    }

</style>


<div class="fix-menu bg-primary" id="menu_id" style="max-width: 500px; ">
        <div>

        <div class="flex justify-around grid-container cursor-pointer">


            
            
            

            


            
            <div id="icon1" class="item1" onclick="scrollToHome()">
                <div style="width: 100%;">
                    <div style="
                    height: 30px;
                    width: 30px;
                    border-radius: 3px; margin: 0 auto;">
 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M341.8 72.6C329.5 61.2 310.5 61.2 298.3 72.6L74.3 280.6C64.7 289.6 61.5 303.5 66.3 315.7C71.1 327.9 82.8 336 96 336L112 336L112 512C112 547.3 140.7 576 176 576L464 576C499.3 576 528 547.3 528 512L528 336L544 336C557.2 336 569 327.9 573.8 315.7C578.6 303.5 575.4 289.5 565.8 280.6L341.8 72.6zM304 384L336 384C362.5 384 384 405.5 384 432L384 528L256 528L256 432C256 405.5 277.5 384 304 384z"/></svg>
                    </div>
                </div>
            </div>
            


            
            <div id="icon2" class="item1" onclick="scrollToUcapan()">
                <div style="width: 100%;">
                    <div style="
                    height: 30px;
                    width: 30px;
                    border-radius: 3px; margin: 0 auto;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M320 64C355.3 64 384 92.7 384 128C384 163.3 355.3 192 320 192C284.7 192 256 163.3 256 128C256 92.7 284.7 64 320 64zM416 376C416 401 403.3 423 384 435.9L384 528C384 554.5 362.5 576 336 576L304 576C277.5 576 256 554.5 256 528L256 435.9C236.7 423 224 401 224 376L224 336C224 283 267 240 320 240C373 240 416 283 416 336L416 376zM160 96C190.9 96 216 121.1 216 152C216 182.9 190.9 208 160 208C129.1 208 104 182.9 104 152C104 121.1 129.1 96 160 96zM176 336L176 368C176 400.5 188.1 430.1 208 452.7L208 528C208 529.2 208 530.5 208.1 531.7C199.6 539.3 188.4 544 176 544L144 544C117.5 544 96 522.5 96 496L96 439.4C76.9 428.4 64 407.7 64 384L64 352C64 299 107 256 160 256C172.7 256 184.8 258.5 195.9 262.9C183.3 284.3 176 309.3 176 336zM432 528L432 452.7C451.9 430.2 464 400.5 464 368L464 336C464 309.3 456.7 284.4 444.1 262.9C455.2 258.4 467.3 256 480 256C533 256 576 299 576 352L576 384C576 407.7 563.1 428.4 544 439.4L544 496C544 522.5 522.5 544 496 544L464 544C451.7 544 440.4 539.4 431.9 531.7C431.9 530.5 432 529.2 432 528zM480 96C510.9 96 536 121.1 536 152C536 182.9 510.9 208 480 208C449.1 208 424 182.9 424 152C424 121.1 449.1 96 480 96z"/></svg>
                    </div>
                </div>
            </div>
            



            
                        <div id="icon3" class="item1" onclick="scrollToGalery()">
                <div style="width: 100%;">
                    <div style="
                    height: 30px;
                    width: 30px;
                    border-radius: 3px; margin: 0 auto;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M128 160C128 124.7 156.7 96 192 96L512 96C547.3 96 576 124.7 576 160L576 416C576 451.3 547.3 480 512 480L192 480C156.7 480 128 451.3 128 416L128 160zM56 192C69.3 192 80 202.7 80 216L80 512C80 520.8 87.2 528 96 528L456 528C469.3 528 480 538.7 480 552C480 565.3 469.3 576 456 576L96 576C60.7 576 32 547.3 32 512L32 216C32 202.7 42.7 192 56 192zM224 224C241.7 224 256 209.7 256 192C256 174.3 241.7 160 224 160C206.3 160 192 174.3 192 192C192 209.7 206.3 224 224 224zM420.5 235.5C416.1 228.4 408.4 224 400 224C391.6 224 383.9 228.4 379.5 235.5L323.2 327.6L298.7 297C294.1 291.3 287.3 288 280 288C272.7 288 265.8 291.3 261.3 297L197.3 377C191.5 384.2 190.4 394.1 194.4 402.4C198.4 410.7 206.8 416 216 416L488 416C496.7 416 504.7 411.3 508.9 403.7C513.1 396.1 513 386.9 508.4 379.4L420.4 235.4z"/></svg>
                    </div>
                </div>
            </div>
            
            



            
            <div id="icon4" class="item1" onclick="scrollToMap()">
                <div style="width: 100%;">
                    <div style="
                    height: 30px;
                    width: 30px;
                    border-radius: 3px; margin: 0 auto;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M576 112C576 100.9 570.3 90.6 560.8 84.8C551.3 79 539.6 78.4 529.7 83.4L413.5 141.5L234.1 81.6C226 78.9 217.3 79.5 209.7 83.3L81.7 147.3C70.8 152.8 64 163.9 64 176L64 528C64 539.1 69.7 549.4 79.2 555.2C88.7 561 100.4 561.6 110.3 556.6L226.4 498.5L399.7 556.3C395.4 549.9 391.2 543.2 387.1 536.4C376.1 518.1 365.2 497.1 357.1 474.6L255.9 440.9L255.9 156.4L383.9 199.1L383.9 298.4C414.9 262.6 460.9 240 511.9 240C534.5 240 556.1 244.4 575.9 252.5L576 112zM512 288C445.7 288 392 340.8 392 405.9C392 474.8 456.1 556.3 490.6 595.2C502.2 608.2 521.9 608.2 533.5 595.2C568 556.3 632.1 474.8 632.1 405.9C632.1 340.8 578.4 288 512.1 288zM472 408C472 385.9 489.9 368 512 368C534.1 368 552 385.9 552 408C552 430.1 534.1 448 512 448C489.9 448 472 430.1 472 408z"/></svg>
                    </div>
                </div>
            </div>
            

                        



            
                        <div id="icon6" class="notif_scroll" style="position: absolute;bottom: 49px;right: 38px;">
                <div class="bubble">Auto Scroll Active</div>
                <div class="pointer"></div>
            </div>
            <div class="item1" id="auto_scroll" onclick="">
                <div style="width: 100%;">
                    <div id="menu_auto_scroll" style="background-color: #4970ea;
                    height: 30px;
                    width: 34px;
                    border-radius: 3px; margin: 0 auto;"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M320 64C178.6 64 64 178.6 64 320C64 461.4 178.6 576 320 576C461.4 576 576 461.4 576 320C576 178.6 461.4 64 320 64zM308.7 451.3L204.7 347.3C200.1 342.7 198.8 335.8 201.2 329.9C203.6 324 209.5 320 216 320L272 320L272 224C272 206.3 286.3 192 304 192L336 192C353.7 192 368 206.3 368 224L368 320L424 320C430.5 320 436.3 323.9 438.8 329.9C441.3 335.9 439.9 342.8 435.3 347.3L331.3 451.3C325.1 457.5 314.9 457.5 308.7 451.3z"/></svg>
                       
                    </div>
                </div>
            </div>
                        



            
            <div id="icon7" class="item1">
                <div style="width: 100%;">
                    <div id="volume" style="background-color: #4970ea;
                    height: 30px;
                    width: 30px;
                    border-radius: 3px; margin: 0 auto;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M532 71C539.6 77.1 544 86.3 544 96L544 400C544 444.2 501 480 448 480C395 480 352 444.2 352 400C352 355.8 395 320 448 320C459.2 320 470 321.6 480 324.6L480 207.9L256 257.7L256 464C256 508.2 213 544 160 544C107 544 64 508.2 64 464C64 419.8 107 384 160 384C171.2 384 182 385.6 192 388.6L192 160C192 145 202.4 132 217.1 128.8L505.1 64.8C514.6 62.7 524.5 65 532.1 71.1z"/></svg>
                    </div>
                </div>
            </div>
            

            

        
        </div>
    </div>
</div>
                <div style="z-index: 999" class="animasi-ucapan el" id="animasi_ucapan" onclick="scrollToUcapan()">
    <div class="box-animasi">
        <div class="header-animasi">
            <p id="nama_tamu" style="font-size: 12px; margin-bottom: 5px !important; font-weight: 600;">Pande</p>
        </div>
        <div class="body-animasi">
            <div id="ucapan_tamu" style="font-size: 10px">Selamat atas pernikahannya</div>
        </div>
    </div>
</div>

        <!-- jQuery -->
<script src="undangan1query.js"></script>
<!-- jQuery Easing -->
<script src="undangan1easing.js"></script>
<!-- Bootstrap -->
<script src="undangan1boostrap.js"></script>
<!-- Waypoints -->
<script src="undangan1weipoint.js"></script>
<!-- Carousel -->
<script src="undangan1carousel.js"></script>
<!-- countTo -->
<script src="undangan1countTo.js"></script>
<!-- Pica JS -->
<script src="undangan1pica.js"></script>
<!-- Cropper JS -->
<script src="undangan1cropper.js"></script>

<script src="undangan1splide.js"></script>



<!-- Stellar -->
<script src="unndanganstellar.js"></script>
<!-- Magnific Popup -->
<script src="undanganpopup.js"></script>
<script src="undanganpopupoptions.js"></script>


<script src="undangancoutdown.js"></script>
<!-- Main -->
<script src="undanganmain.js"></script>

<script src="undangananime.js"></script>
<script src="undanganaos.js"></script>
<script src="undanganpure.js"></script>
<script src="undanganparticles.js"></script>







<script>
    localStorage.setItem('paket', 2);
</script>

            <script src="undangangsap.js"></script>
    <script src="undanganscrol.js"></script>
    <script src="undanganflip.js"></script>
    <script src="undangananimasi.js"></script>
    



<script>


    // var d = new Date(new Date().getTime() + 10*86400000);
    // var da = new Date(new Date().getTime());
    // var d = new Date("2021-10-5");
        AOS.init({
        duration: 3000,
    });
        if ($('.slide-story').length) {
        let splideStory = new Splide('.slide-story', {
            type      : 'fade',
            rewind    : true,
            autoplay: false,
            interval   : 5000,
            speed: 3000,
            rewindSpeed: 2000,
            pagination: true,
            cover: true,
            updateOnMove: true,
            arrows     : true,
            lazyLoad: 'nearby',
        }).mount();
    }
    $(document).ready(function() {
        runLazy();

    });

    function runLazy() {
        const lazyBackgrounds = $('.lazy-background');
        const lazyImages = $('.lazy-img');

        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const target = $(entry.target);

                    // Lazy-load untuk background image
                    if (target.hasClass('lazy-background')) {
                        const bgImage = target.data('bg');
                        target.css('background-image', 'url(' + bgImage + ')');
                        target.removeClass('lazy-background');
                    }

                    // Lazy-load untuk img dengan kelas lazy-img
                    if (target.hasClass('lazy-img')) {
                        const imgSrc = target.data('src');
                        target.attr('src', imgSrc);
                        target.removeClass('lazy-img');
                    }

                    observer.unobserve(entry.target);
                }
            });
        });

        lazyBackgrounds.each(function() {
            observer.observe(this);
        });

        lazyImages.each(function() {
            observer.observe(this);
        });
    }

    
            $('p').each(function(id) {
            $(this).addClass('fun-p-' + id);
        });
            $('div').each(function(id) {
            $(this).addClass('fun-div-' + id);
        });
            $('h1').each(function(id) {
            $(this).addClass('fun-h1-' + id);
        });
            $('h2').each(function(id) {
            $(this).addClass('fun-h2-' + id);
        });
            $('h3').each(function(id) {
            $(this).addClass('fun-h3-' + id);
        });
            $('h4').each(function(id) {
            $(this).addClass('fun-h4-' + id);
        });
            $('h5').each(function(id) {
            $(this).addClass('fun-h5-' + id);
        });
            $('h6').each(function(id) {
            $(this).addClass('fun-h6-' + id);
        });
            $('span').each(function(id) {
            $(this).addClass('fun-span-' + id);
        });
            $('li').each(function(id) {
            $(this).addClass('fun-li-' + id);
        });
            $('ul').each(function(id) {
            $(this).addClass('fun-ul-' + id);
        });
            $('ol').each(function(id) {
            $(this).addClass('fun-ol-' + id);
        });
            $('a').each(function(id) {
            $(this).addClass('fun-a-' + id);
        });
            $('img').each(function(id) {
            $(this).addClass('fun-img-' + id);
        });
            $('small').each(function(id) {
            $(this).addClass('fun-small-' + id);
        });
    

    

    // openShop();

    // AUTO SCROLL
// var output = $('h1');
var isPaused = false;
var time = 0;
// var t = window.setInterval(function() {
//     if(!isPaused) {
//         time++;
//         window.scrollBy(0,0.5);
//     }
// }, 10);
var scroll = 25;
var urlParams = new URLSearchParams(window.location.search);
var scrollValue = urlParams.get('scroll');
if (scrollValue) {
    scroll = scrollValue;
}

var cekVia = localStorage.getItem('via');
    if (cekVia) {
        var element = $('input[name="kupon"]');
        element.val(cekVia);
    }

function runAutoScroll() {
    var t = window.setInterval(function() {
        if(!isPaused) {
            time++;
            window.scrollBy(0,1);
        }
    }, scroll);
}



//with jquery
$('#auto_scroll').on('click', function(e) {
    e.preventDefault();
    if (isPaused) {
        $('#menu_auto_scroll').css('background-color', '#4970ea');
        isPaused = false;
        $('.notif_scroll').show();
    } else {
        isPaused = true;
        $('#menu_auto_scroll').css('background-color', 'transparent');
        $('.notif_scroll').hide();
    }

});

// END AUTO SCROLL


        // modal
    function openEditModal(modalId) {
        $('#'+modalId).show();
        anime({
            targets: '#'+modalId+'-page1',
            translateY: 0,
            opacity: 1,
            duration: 250,
            easing: 'easeInOutSine'
        });
        console.log('open modal');

        window.dataLayer.push({
            'event': 'edit_list_view'
        });
    }

    
    function closeEditModal(modalId) {
        $('.onedit-class').removeClass('onedit-class');
        anime({
            targets: '#'+modalId+'-page1',
            translateY: 400,
            opacity: 0,
            duration: 250,
            easing: 'easeInOutSine'
        });

        setTimeout(function() {
            $('#'+modalId).hide();
            toEdit1(modalId)
        }, 250);
    }

    function registrasiRe() {
            // Serialize form data
            var formData = new FormData($("#login-form")[0]);
            var formUrl = $("#login-form").attr('action');

            // var formData = $("#"+modalId+"-form").serialize();
            var textBtn = $('.btn-login-re').text();
            $('.btn-login-re').text('Loading...');

            console.log(formData);
            $('button, input, textarea').prop('disabled', true);
            // Make AJAX POST request
            $.ajax({
                type: "POST",
                url: formUrl,
                data: formData,
                processData: false,  // Prevent jQuery from automatically processing the data
                contentType: false,
                success: function(response){
                    var jsonResponse = JSON.parse(response);
                    var status = jsonResponse['status'];
                    var msg = jsonResponse['msg'];

                    if (status == 1) {
                        closeEditModal('login');
                        openEditModal('data-pernikahan');
                        $('#notif-login-re').text('')
                    } else {
                        $('#notif-login-re').text(msg)
                    }
                    $('button, input, textarea').prop('disabled', false);
                    $('.btn-login-re').text('Masuk Dan Edit');
                },
                error: function(errjqXHR, textStatus, errorThrownor){
                    console.log("Error:", errjqXHR);
                    $('#notif-login-re').text('Terjadi kesalahan, periksa koneksi internet dan coba lagi')
                    $('button, input, textarea').prop('disabled', false);
                    $('.btn-login-re').text('Masuk Dan Edit');
                    // showError()
                    // Handle the error
                }
            });
    }

    


    var d = new Date("Fri Oct 22 2021 10:31:00");
    // console.log(d.toDateString());
    // var d = new Date(2021, 10, 5, 12, 0, 0, 0);

    let searchParams2 = new URLSearchParams(window.location.search)
    let demoParam = searchParams2.get('demo')
    let contohParam = searchParams2.get('contoh')

    if (demoParam == 1) {
           // tema slide
      const awal1 = $('.awal1')
      awal1.remove();
      const pages1 = $('.pages1');
      if (pages1) {
        const body = pages1.closest('body');
        body.attr('style', 'max-width:440px; margin: 0 auto; width: 100%');
        pages1.append(`
        <div class="navigasi-realtime" style="position: absolute; z-index:99;bottom:7rem;left:2rem;">
            <div style="display:flex; width:100%;">
               <button type="button" onclick="prev()"> <svg class=" w-10 h-10 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="width:50px; height:50px; background-color: #fff;border-radius: 1.25rem;opacity: 0.9;fill: #2d3748;" >
                    <path fill-rule="evenodd" d="M13.729 5.575c1.304-1.074 3.27-.146 3.27 1.544v9.762c0 1.69-1.966 2.618-3.27 1.544l-5.927-4.881a2 2 0 0 1 0-3.088l5.927-4.88Z" clip-rule="evenodd"/>
                </svg>
                </button>
                <button type="button" onclick="next()">
                    <svg class=" w-10 h-10 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="width:50px; height:50px; background-color: #fff;border-radius: 1.25rem;opacity: 0.9;fill: #2d3748; margin-left: 7px;">
                    <path fill-rule="evenodd" d="M10.271 5.575C8.967 4.501 7 5.43 7 7.12v9.762c0 1.69 1.967 2.618 3.271 1.544l5.927-4.881a2 2 0 0 0 0-3.088l-5.927-4.88Z" clip-rule="evenodd"/>
                </svg>
                    </button>
            </div>

            </div>`
        )
      }
        // tema biasa
      $('.awal').hide();
      $("#playAudio").prop("muted",true);
        $("#playAudioS").prop("muted",true);
    }

    $('#wa3').hide();


    $('#ucapan_2').bind('input propertychange', function() {
        $('#wa2').show();
    });

    $("#hadir_id").change(function() {
        var val = $(this).val();
        if(val == "1") {
            $('#wa3').show();
            $('.custom-form').show();
            $('.custom-form').find('input, textarea, select').prop('disabled', false);
            $('#jumlah_datang_id').val('1');
        }
        else {
            $('#wa3').hide();
            $('.custom-form').hide();
            $('.custom-form').find('input, textarea, select').prop('disabled', true);
            $('#jumlah_datang_id').val('0');
        }
  });

    $(".status_radio").change(function() {
        var val = $(this).val();
        if(val == "1") {
            $('#wa3').show();
            $('#jumlah_datang_id').val('1');
        } else {
            $('#wa3').hide();
            $('#jumlah_datang_id').val('0');
        }
    });

  $("#hadir_id_popup").change(function() {
        var val = $(this).val();
        if(val == "1") {
            $('#wa3_popup').show();
            $('#formContainer2').show();
            $('#formContainer2').find('input, textarea, select').prop('disabled', false);
            $('#jumlah_datang_id_popup').val('1');
        }
        else {
            $('#wa3_popup').hide();
            $('#jumlah_datang_id_popup').val('0');
            $('#formContainer2').hide();
            $('#formContainer2').find('input, textarea, select').prop('disabled', true);
        }
  });

    $("#konfirmasi-hadiah").submit(function (e) {
        e.preventDefault();
        let nama = $('#nama').val();
        let jumlah = $('#jumlah').val();
        let norek = $('input[name=norek]:checked').val();
        let rekening = norek.split('|');
        let phoneNumber = '087755546324';
        phoneNumber = phoneNumber.replace(/^0/, '62');

        if (nama && jumlah && norek) {
            let message = 'Halo, saya ' + nama + ' ingin konfirmasi pemberian hadiah sejumlah Rp. ' + jumlah + ' melalui nomor Rekening' + rekening[1] + ' atas nama '+ rekening[0] +'. Bisa di check yaa.';
            let url = `https://wa.me/${phoneNumber}?text=` + encodeURIComponent(message);
            window.open(url, '_blank');
        }
    });

    let jamStart1 = $('#jam_start1').val();
    let jamEnd1 = $('#jam_end1').val();
    $('#sampai_selesai_check').click(function () {
        if (jamStart1 == null || jamEnd1 == null) {
            $('#jam_start1').val('08:00');
            $('#jam_end1').val('08:00');
        }

    })

    let jamStart2 = $('#jamStart2').val();
    let jamEnd2 = $('#jam_end2').val();

    $('#sampai_selesai_check2').click(function () {
        console.log(jamEnd2);
        if (jamStart2 == null || jamEnd2 == null) {
            $('#jamStart2').val('08:00');
            $('#jam_end2').val('08:00');
        }
    });

  





    // $('#bantu_bayar').on('click touchstart tap', function () {
    //     console.log('testing');
    //     $('#modal-bayar').modal('show');
    // })
    
    $('#filed_kehadiran').show()


    $('.bantu_bayar2').on('click touchstart tap', function () {
        console.log('testing');
        $('#modal-bayar').modal('show');
        return 1;
    })


    $('.rek_copy').on('click touchstart tap', function () {
        console.log('clicked');
        $(this).text('copied!');

        alertMe($(this));
        return 1;
    })

    function alertMe(btn) {
        setInterval(function(){
            btn.text('copy');
        },1000);
    }



  $('#btn_titip').on('click touchstart tap', function () {
    console.log('testing');
    pembayaran()
  })





    // munculkan demo button
    var urlParams = new URLSearchParams(window.location.search);
    var sectionName = urlParams.get('contoh');
    if (sectionName == 1) {
        $('#head_buat').show();
        $('#animasi_ucapan').remove();
    }

    if (demoParam == 1) {
        $('#animasi_ucapan').remove();
    }





    simplyCountdown('.simply-countdown-one', {
        year: 2026,
        month: 3,
        day: 30,
        enableUtc: false,
        hours: 13, // Default is 0 [0-23] integer
        minutes: 0, // Default is 0 [0-59] integer
        seconds: 0, // Default is 0 [0-59] integer
    });

    function openLink2(url) {
        window.location.href = url;
    }

    if ($('#salamAgama').val() == '6') {
        $('#customAgamaInput').show();
    } else {
        $('#customAgamaInput').hide();
    }

    // Tampilkan input teks jika pilihan "Custom" dipilih
    $('#salamAgama').change(function() {
        if ($(this).val() == '6') {
            $('#customAgamaInput').show();
        } else {
            $('#customAgamaInput').hide();
        }
    });
    $(".simply-countdown").attr("data-id", 9079);
    $(".countdown-acara").append(`
    <div data-aos="fade-up" style="width:100%; justify-content:center;">
        <a onclick="saveToCalendar()" class="btn btn-save-the-date" style="    position: relative;
        display: flex;
        margin: 0 auto;
        color: #fff;
        justify-content: center;
        align-content: center;
        align-items: center;
        width: fit-content;
        padding: 5px 10px;
        border-radius: 5px;
        font-size: 12px;
        margin-top: 10px;
        background: #000000;
        color: white;
        border: 1.5px solid #000000;
        fill: white;" target="_blank">Save To Calendar</a>
    </div>`
    );
        function saveToCalendar() {
        var event = "Pernikahan Ali Sandi, S.P &amp; Ays, S.Pd";
        var month = '3';
        var date = '30';
        var th  = '2026';
        var link = 'https://calendar.google.com/calendar/u/0/r/eventedit?text='+event+'&dates='+th+month+date+'T080000/'+th+month+date+'T090000';
        window.open(link, '_blank');
    }
    
    $(document).ready(function() {
        

        
        
                
        $("#data-pernikahan-form").submit(function() {
            // Disable the submit button to prevent double-click
            $("#btn-id-buat-re").prop("disabled", true);

            // Optionally, you can re-enable the button after a delay
            setTimeout(function() {
                $("#btn-id-buat-re").prop("disabled", false);
            }, 5000); // 5000 milliseconds (adjust as needed)

            window.dataLayer.push({
                'event': 'buat_acara_baru_re',
                // 'jenis_acara': acara,
                // 'date_acara': date
            });

            return true;
        });


        setTimeout(function () {
            anime({
                targets: '#kucing_imut',
                opacity: 0,
                duration: 1000,
            });
            setTimeout(function () {
                $('#kucing_imut').hide();
            }, 1000);

        }, 2000);


        var cekUcapan = localStorage.getItem('isiUcapan');
        if (cekUcapan) {
                                            }


        // validasi max 10 input peserta
        $("#jumlah_datang_id").on("blur", function() {
            var value = parseInt($(this).val());

            if (isNaN(value) || value < 0 || value > 10) {
                // alert("Please enter a valid integer between 0 and 10.");
                $(this).val("");
                $('#alert_data_ucapan').text('Maksimal jumlah hadir adalah 10 orang');
            } else {
                $('#alert_data_ucapan').text('');
            }
        });



        var myParam = location.search.split('kpd=')[1];
        $('#konfir_nama').val(myParam);
        // console.log(myParam);
        $('#notif_wa').hide();

        localStorage.setItem('9079', true);
        localStorage.setItem('nama', myParam);

        var cekNama = localStorage.getItem('9079-nama');

        if (cekNama == 'undefined' || cekNama == '' || cekNama == null) {
            $('#qrcode_id').hide();
            if (cekNama != myParam) {
                localStorage.setItem('9079-nama', myParam)
            }
        } else {
            $('#qrcode_id').show();
        }

        var idTamu = new URLSearchParams(window.location.search).get('id');
        if(idTamu) localStorage.setItem('9079-idTamu', idTamu)

        setInterval(function () {
            animUcapan()
        }, 6000);

        setTimeout(function() {
            loadUcapan();
        }, 3000);



        anime({
            targets: '.flower-anim',
            rotate: {
                value: 30,
                duration: 3000,
                easing: 'easeInOutSine'
            },
            scale: 1.5,
            loop: true,
            direction: 'alternate',
            easing: 'easeInOutSine'
        });

        // $('a[href^="http"]').attr('target','_blank');





    });


    // ketika klik buka undangan

    $('#music_list_id').on('change', function() {
        var selectedOption = $(this).val();
        var audio = document.getElementById('prev_mp3');
        console.log(selectedOption);
        $('#prev_mp3').attr('src', '/'+selectedOption);
        $('#prev_mp3').trigger('load');
        audio.pause();
        audio.currentTime = 0; // Reset to the beginning
        $('#play_mp3').text('Play Audio');
    });

    function playMp3() {
        var audio = document.getElementById('prev_mp3');

        if (audio.paused) {
            audio.play();
            $('#play_mp3').text('Pause Audio');
        } else {
            audio.pause();
            audio.currentTime = 0; // Reset to the beginning
            $('#play_mp3').text('Play Audio');
        }

    }


    $("#push_ucapan").submit(function(e) {

        e.preventDefault(); // avoid to execute the actual submit of the form.
        var buttonText = $('#tombol_kirim_2').text();
        $('#tombol_kirim_2').prop('disabled', true);
        $('#konfir_nama_2').prop('readonly', true);
        $('#ucapan_2').prop('readonly', true);
        $('#tombol_kirim_2').text('Mengirim ...');


        var form = $(this);
        var actionUrl = form.attr('action');


        var formTambahan = [];

        $("#formContainer .form-value").each(function(){
            formTambahan.push({
                field_name: $(this).data('field_name'),
                value: $(this).val().trim()
            })
        })

        // Display the collected data in the console
        // console.log(formData2);

        // var formTambahan = '';
        // if (formData2.length > 0) {
        //     var formTambahan = formData2.join(", ");
        // }

        var csrfToken = $('meta[name="csrf-token"]').attr('content');

        var myData = {
            _token: csrfToken,
            pernikahan_id: '9079',
            nama: $('#konfir_nama_2').val(),
            ucapan: $('#ucapan_2').val(),
            formTambahan,
            wa_tamu: $('#wa_tamu').val(),
            email_tamu: $('#email_tamu').val(),
            notif: $('#notif').val(),
            ket_hadir: $('#hadir_id').val(),
            jumlah: $('#jumlah_datang_id').val()
        };


        // var myData = form.serialize();
        // console.log(myData);

        $.ajax({
            type: "POST",
            url: actionUrl,
            data: myData, // serializes the form's elements.
            beforeSend: function(xhr) {
                        // Set the CSRF token in the request header
                        xhr.setRequestHeader("X-CSRFToken", csrfToken);
                    },
            success: function(data)
            {
                loadUcapan()
                $('#tombol_kirim_2').prop('disabled', false);
                $('#ucapan_2').val('');
                $('#konfir_nama_2').prop('readonly', false);
                $('#ucapan_2').prop('readonly', false);
                $('#tombol_kirim_2').text(buttonText);
                $('#push_ucapan').after('<p id="notif-submt" style="line-height: 14px;font-weight: 200;font-size: 12px;margin-top: 20px;background-color: #fff8d5;border-radius: 5px;color: #3b3b3b;padding: 5px;">Thank you, Your message has been successfully submitted</p>');
                pembayaran()
                openShop()
                localStorage.setItem('isiUcapan', true);
                const kpd = "Bapak Budi"
                if(kpd){
                  localStorage.setItem('ucapanForm-9079-' + "Bapak+Budi", true);
                }
                isUserFilledKehadiranForm()
                setTimeout(function() {
                    $('#notif-submt').hide()
                }, 7000);
            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connect.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                console.log('Kirim ucapan gagal: '+ msg);
                $('#tombol_kirim_2').prop('disabled', false);

                $('#konfir_nama_2').prop('readonly', false);
                $('#ucapan_2').prop('readonly', false);
                $('#tombol_kirim_2').text('Kirim');


            },

        });

    });

    function isUserFilledPopupKehadiranForm(){
      const key = 'ucapanPopup-9079-' + "Bapak+Budi"
      const isFilled = localStorage.getItem(key) ? true : false
      if(isFilled){
        $('#filed_kehadiran').css('display', 'none')
        $('#hadir_id').val(1)
        $('#formContainer').remove()
        $('.custom-form').remove()
        $('#notifPopupFill').css('display', 'block')
      }
    }
    isUserFilledPopupKehadiranForm()

    function isUserFilledKehadiranForm(){
      const key = 'ucapanForm-9079-' + "Bapak+Budi"
      const isFilled = localStorage.getItem(key) ? true : false
      if(isFilled){
        $('#formContainer2').remove()
        $('#kehadiran-modal-body').remove()
        closeKehadrianModal()
        $('#filed_kehadiran').remove()
        $('#wa3').remove()
        $('.custom-form').remove()
        $('#notifPopupFill').css('display', 'block')
      }
    }
    isUserFilledKehadiranForm()

    function resetKehadiran(){
      const ucapanPopupKey = 'ucapanPopup-9079-' + "Bapak+Budi"
      const ucapanFormKey = 'ucapanForm-9079-' + "Bapak+Budi"
      localStorage.removeItem(ucapanPopupKey)
      localStorage.removeItem(ucapanFormKey)
      location.reload()
    }

    $("#push_ucapan_popup").submit(function(e) {

        e.preventDefault(); // avoid to execute the actual submit of the form.


        $('#tombol_kirim_2_popup').prop('disabled', true);
        $('#konfir_nama_2_popup').prop('readonly', true);
        $('#ucapan_2_popup').prop('readonly', true);
        $('#tombol_kirim_2_popup').text('Mengirim ...');

        var form = $(this);
        var actionUrl = form.attr('action');

        var formTambahan = [];
        $("#formContainer2 .form-value").each(function(){
          formTambahan.push({
              field_name: $(this).data('field_name'),
              value: $(this).val().trim()
          })
        })

        var formDataObj = form.serializeArray().reduce(function(obj, item) {
            obj[item.name] = item.value;
            return obj;
        }, {});
        formDataObj.formTambahan = formTambahan;
        var myData = $.param(formDataObj);

        $.ajax({
            type: "POST",
            url: actionUrl,
            data: myData, // serializes the form's elements.
            success: function(data)
            {
                loadUcapan()
                $('#tombol_kirim_2_popup').prop('disabled', false);
                $('#ucapan_2_popup').val('');
                $('#konfir_nama_2_popup').prop('readonly', false);
                $('#ucapan_2_popup').prop('readonly', false);
                $('#tombol_kirim_2_popup').text('Kirim');
                pembayaran()
                openShop()
                // localStorage.setItem('isiUcapan_9079', true);
                localStorage.setItem('isiUcapan', true);
                closeKehadrianModal()
                // console.log('DARI POPUP');
                const kpd = "Bapak Budi"
                if(kpd){
                  localStorage.setItem('ucapanPopup-9079-' + "Bapak+Budi", true);
                }
                isUserFilledPopupKehadiranForm()
            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connect.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                console.log('Kirim ucapan gagal: '+ msg);
                $('#tombol_kirim_2_popup').prop('disabled', false);

                $('#konfir_nama_2_popup').prop('readonly', false);
                $('#ucapan_2_popup').prop('readonly', false);
                $('#tombol_kirim_2_popup').text('Kirim');


            },

        });

        });




    $(document).on('click', '.pagination a', function(event){
        event.preventDefault();
        var page = $(this).attr('href').split('page=')[1];
        fetch_data(page);
    });

    
    
    
    
    function aktifkanQRCode() {
        var cekNama = localStorage.getItem('9079-nama');

        if (cekNama == 'undefined' || cekNama == '' || cekNama == null) {
            $('#qrcode_id').hide();
        } else {
            $('#qrcode_id').show();
        }
    }


    $('.awal').on('click', function () {
        opened();
    })

    //hide the begining


    function opened() {
        let param = searchParams.get('kpd');
        // Cek key open
        if (!localStorage.getItem('open-9079')) {
            let data = {
                '_token': 'l5JWjBT2gJYijjEfxPW4VCU9wpIp4zTVYhWhwAfE',
            };

            // Jika `kpd` kosong, kirim data tanpa `nama_tamu`
            if (param) {
                data['nama_tamu'] = param;
            }

            $.ajax({
                url: '/count-open/9079',
                method: 'POST',
                data: data,
                success: function(response) {
                    // set true
                    localStorage.setItem('open-9079', true);
                },
                error: function(xhr, status, error) {
                    console.error('Gagal menghitung:', error);
                }
            });
        }

        $('#konfir_nama').val(param);
        if ($("#playAudio").length) {
            $("#playAudio").get(0).play();
        }
        if ($("#playAudioS").length) {
            $("#playAudioS").get(0).play(); //play musik
        }


        aktifkanQRCode();
        // document.documentElement.requestFullscreen();  //fullscreen
        setTimeout(function() {
            // bukaTamu();
        }, 10000);
        setTimeout(function() {
            // bukaProtokol();
        }, 5000);

                    runAutoScroll();
        
        

        anime({
            targets: '.awal',
            translateY: 400,
            opacity: 0,
            duration: 500,
            easing: 'easeInOutSine'
        });

        setTimeout(function() {
            $(this).hide();
            $('.awal').remove();
        }, 500);
        runAnimationOrnament();
        runAnimationLoop();
        runAnimationWithoutScrollTrigger();
    }


    
    // count undangan dilihat
    $(document).ready(function() {
            // cek user pernah akses atau belum
            if (!localStorage.getItem('akses-9079')) {
                $.ajax({
                    url: '/count-view/9079',
                    method: 'POST',
                    data: {
                        '_token': 'l5JWjBT2gJYijjEfxPW4VCU9wpIp4zTVYhWhwAfE', // Token CSRF untuk keamanan
                        'pernikahan_id': 9079
                    },
                    success: function(response) {
                        console.log('Berhasil menghitung view');
                        // set true
                        localStorage.setItem('akses-9079', true);
                    },
                    error: function(xhr, status, error) {
                        console.error('Gagal menghitung view:', error);
                    }
                });
            }
        });

    // count copy rekening
    $('.rek_copy').click(function (e) {
        let norek = $(this).data("rek");
        navigator.clipboard.writeText(norek);

        e.preventDefault();
        if (!localStorage.getItem('copy-rek-9079')) {
            let data = {
                '_token': 'l5JWjBT2gJYijjEfxPW4VCU9wpIp4zTVYhWhwAfE',
            };

            // Jika `kpd` kosong, kirim data tanpa `nama_tamu`
            if (param) {
                data['nama_tamu'] = param;
            }

            $.ajax({
                url: '/count-copy-rek/9079',
                method: 'POST',
                data: data,
                success: function(response) {
                    // set true
                    localStorage.setItem('copy-rek-9079', true);
                },
                error: function(xhr, status, error) {
                    console.error('Gagal menghitung:', error);
                }
            });
        }
    });


    // Count maps click
    $('#c-acara-id a').click(function (e) {
        if (!localStorage.getItem('open-maps-9079')) {
            let data = {
                '_token': 'l5JWjBT2gJYijjEfxPW4VCU9wpIp4zTVYhWhwAfE',
            };

            // Jika `kpd` kosong, kirim data tanpa `nama_tamu`
            if (param) {
                data['nama_tamu'] = param;
            }

            $.ajax({
                url: '/count-open-maps/9079',
                method: 'POST',
                data: data,
                success: function(response) {
                    // set true
                    localStorage.setItem('open-maps-9079', true);
                },
                error: function(xhr, status, error) {
                    console.error('Gagal menghitung:', error);
                }
            });
        }
    });

    // count gallery
    $('#fh5co-gallery-list a,#galleryGrid a').click(function (e) {
        if (!localStorage.getItem('open-gallery-9079')) {
            let data = {
                '_token': 'l5JWjBT2gJYijjEfxPW4VCU9wpIp4zTVYhWhwAfE',
            };

            // Jika `kpd` kosong, kirim data tanpa `nama_tamu`
            if (param) {
                data['nama_tamu'] = param;
            }

            $.ajax({
                url: '/count-open-gallery/9079',
                method: 'POST',
                data: data,
                success: function(response) {
                    // set true
                    localStorage.setItem('open-gallery-9079', true);
                },
                error: function(xhr, status, error) {
                    console.error('Gagal menghitung:', error);
                }
            });
        }

    });
    


    function getRndInteger(min, max) {
        return Math.floor(Math.random() * (max - min + 1) ) + min;
    }

    function bukaTamu() {
        var cekDevice = localStorage.getItem('9079');
        if (cekDevice) {
            $('.modal').modal('hide');
        } else {
            $('#exampleModal2').modal({backdrop: 'static', keyboard: false})
        }
    }

    function bukaProtokol() {

            $('#modal_protokol').modal({backdrop: 'static', keyboard: false})

    }

    function belum(params) {
        $('#exampleModal').modal({backdrop: 'static', keyboard: false})
    }

    function whatsappCheck(){
      const wa_number = '087755546324'
      const active = '2'
      if(active > 0 && !wa_number){
        openEditModal('notifikasi')
        $('#warning_wa').css('display', 'block')
        $('#wa_id').focus()
        $('#header_kd_notifikasi').css('pointer-events', 'none')
        $('#close_modal_element').css('pointer-events', 'none')
      }
    }
    whatsappCheck()

    function sanitizeHtml(str) {
      if (!str) return '';
      return str.replace(/<(?!\/?(b|i|u)\b)[^>]*>/gi, ''); // Only <b>, <i>, <u>
    }

    let searchParams = new URLSearchParams(window.location.search)
    searchParams.has('kpd')
    let param = sanitizeHtml(searchParams.get('kpd'))
    var cekNama = sanitizeHtml(localStorage.getItem('9079-nama'));
    // console.log(param)

        if (param == null || param == '' || param == 'null') {
            $('#konfir_nama_2').val(cekNama)
            $('#konfir_nama_2_popup').val(cekNama)
            $("#kpd").html(cekNama)
            $("#kpdn").html(cekNama)
            $("#kpd2").html(cekNama)
        } else {
            $('#konfir_nama_2').val(param)
            $('#konfir_nama_2_popup').val(param)
            $("#kpd").html(param)
            $("#kpdn").html(param)
            $("#kpd2").html(param)
        }





    $("#volume").click(function () {
		var bool = $("#playAudio").prop("muted");
        $("#playAudio").prop("muted",!bool);
        $("#playAudioS").prop("muted",!bool);



        if (bool === true) {
            $(this).css('background-color', '#4970ea');
        } else {
            $(this).css('background-color', '#4970ea00');
        }
    })



    function scrollToMap() {
        document.querySelector('.map_id2').scrollIntoView({behavior: 'smooth'});
    }

    function scrollToUcapan() {
        openKehadiranModal();
        document.querySelector('#push_ucapan').scrollIntoView({behavior: 'smooth'});
    }

    function scrollToGalery() {
        document.querySelector('#galery_id').scrollIntoView({behavior: 'smooth'});
    }

    function scrollToHome() {
        document.querySelector('#page').scrollIntoView({behavior: 'smooth'});
    }



    function konfirAjax() {

    }

    function closeModal(id){
        $(id).hide();
    }






    function onYouTubeIframeAPIReady() {
        var player;
        player = new YT.Player('youtube-video', {
        events: {
            'onReady': onPlayerReady,
        }
        });
    }

    // Function to autoplay the video when it's ready
    function onPlayerReady(event) {
        // You can adjust the threshold as needed
        var threshold = 600; // Number of pixels from the bottom to start autoplay
        var player = event.target;
        var videoTop = $('#youtube-video').offset().top;
        var autoplayStarted = false;

        $(window).on('scroll', function () {
        var scrollPos = $(this).scrollTop();
        var videoPos = videoTop - $(window).height() + threshold;

        if (scrollPos >= videoPos && !autoplayStarted) {
            player.playVideo();
            autoplayStarted = true;
            console.log('PLAY VIDEONYAA');

                // pause auto scroll
                isPaused = true;
                $('#menu_auto_scroll').css('background-color', 'transparent');
                $('.notif_scroll').hide();

                // pause music
                $("#playAudio").prop("muted",true);
                $("#playAudioS").prop("muted",true);
                $(this).css('background-color', '#4970ea00');
        }
        });
    }


    // 60% SCROLL
    function calculateScrollPercentage() {
        const scrollTop = $(window).scrollTop();
        const windowHeight = $(window).height();
        const pageHeight = $(document).height();

        return (scrollTop / (pageHeight - windowHeight)) * 100;
    }


    $(window).scroll(function() {
        const scrollPercentage = calculateScrollPercentage();

        // If the user has scrolled 60% or more, open the modal
        if (scrollPercentage >= 60) {

            var cekUcapan = localStorage.getItem('isiUcapan_9079');
            if (!cekUcapan) {
                openKehadiranModal()
            }



            // Unbind the scroll event to prevent the modal from reopening
            $(window).off("scroll");
        }
    });

    function closeKehadrianModal() {
        anime({
            targets: '#kehadiran-modal-body',
            translateY: 400,
            opacity: 0,
            duration: 500,
            easing: 'easeInOutSine'
        });

        setTimeout(function() {
            $("#menu-kehadiran-bawah").css("opacity", 0);
            $("#menu-kehadiran-bawah").css("transform", "scale(2.5)");
            anime({
                targets: '#menu-kehadiran-bawah',
                scale: 1,
                opacity: 1,
                duration: 1000,
                easing: 'easeInOutSine'
            });
        }, 400);

        setTimeout(function() {
            $('#kehadiran-modal').hide();

        }, 500);



    }


    function openKehadiranModal() {
        // alert(demoParam)
        if (contohParam != 1) {
            if (demoParam == null) {
                $('#kehadiran-modal').show();
                // alert('haloo');
                $("#menu-kehadiran-bawah").css("opacity", 0);
                anime({
                    targets: '#kehadiran-modal-body',
                    translateY: 0,
                    opacity: 1,
                    duration: 500,
                    easing: 'easeInOutSine'
                });
            }
        }

    }



    function closeAmplopModal() {
        anime({
            targets: '#amplop-modal-body',
            translateY: 400,
            opacity: 0,
            duration: 500,
            easing: 'easeInOutSine'
        });

        setTimeout(function() {
            $('#amplop-modal').hide();

        }, 500);



    }


    function openAmplopModal() {
        $('#amplop-modal').show();
        anime({
            targets: '#amplop-modal-body',
            translateY: 0,
            opacity: 1,
            duration: 500,
            easing: 'easeInOutSine'
        });
        console.log('open modal');
    }


    // Start Gift
    function closeGiftModal() {
        anime({
            targets: '#gift-modal-body',
            translateY: 400,
            opacity: 0,
            duration: 500,
            easing: 'easeInOutSine'
        });

        setTimeout(function() {
            $('#gift-modal').hide();

        }, 500);



    }


    function openGiftModal() {
        $('#gift-modal').show();
        anime({
            targets: '#gift-modal-body',
            translateY: 0,
            opacity: 1,
            duration: 500,
            easing: 'easeInOutSine'
        });
        console.log('open modal');

        window.dataLayer.push({
            'event': 'gift_list_view'
        });
    }

    var idGift = '';
    var koinGift = '';
    var imgGift = '';
    function addToCartGift(id, koin, img) {
        idGift = id;
        koinGift = koin;
        imgGift = img;

        $('.grid-item-gift').removeClass('selected-gift');
        $('.btn_gift_item').removeClass('btn_gift_item_selec');
        $('.btn_gift_item').text('Select');


        $('#btn_sel_gift_'+id).text('Selected');
        $('#list_gift_'+id).addClass('selected-gift');
        $('#btn_sel_gift_'+id).addClass('btn_gift_item_selec');

        $('#total_koin_gift').text(koin);

        $('#konfirmasi-btn-gift').prop('disabled', false);

        // set di halaman confirm
        $('#confirm-gift-img').prop('src', img);
        $('#confirm-koin-id').text(koin);
        $('.total-gift-id').text(rupiah(koin*1500));
        $('#gift-id-send').val(id);
    }

    function toConfirmGift() {

        // gtag('event', 'titip_kado_konfir');
        window.dataLayer.push({
            'event': 'gift_konfir'
        });

        anime({
            targets: '#div-list-gift',
            translateX: -200,
            opacity: 0,
            duration: 200,
            easing: 'easeInOutSine'
        });

        setTimeout(function() {
            anime({
                targets: '#div-confirm-gift',
                translateX: 0,
                opacity: 1,
                duration: 200,
                easing: 'easeInOutSine'
            });

            $('#gift-konfir').show();

        }, 100);




        setTimeout(function() {
            $('#gift-pilih').hide();
            $('#gift-xendit').hide();

        }, 200);
    }

    function toListGift() {
        anime({
            targets: '#div-confirm-gift',
            translateX: 200,
            opacity: 0,
            duration: 200,
            easing: 'easeInOutSine'
        });

        setTimeout(function() {


            anime({
                targets: '#div-list-gift',
                translateX: 0,
                opacity: 1,
                duration: 200,
                easing: 'easeInOutSine'
            });

            $('#gift-pilih').show();

        }, 100);




        setTimeout(function() {
            $('#gift-konfir').hide();
            $('#gift-xendit').hide();

        }, 200);
    }


    var uuidGift = '';
    $("#submit-gift").submit(function(){
        // var harga = $('#total_bayar_data').val();
        $.ajax({
            url:$(this).attr("action"),
            data:$(this).serialize(),
            type:$(this).attr("method"),
            dataType: 'html',
            beforeSend: function() {
                $("input").attr("disabled",true);
                $("button").attr("disabled",true);
                $("#btn-pembayaran-gift").html('Memproses ...');
            },
            complete:function() {
                $("input").attr("disabled",false);
                $("button").attr("disabled",false);
                $("#btn-pembayaran-gift").html('CHECKOUT');
            },
            success:function(hasil) {
                // console.log(hasil);
                // gtag('event', 'titip_kado_submit', {
                //     'value' : 69000,
                //     'currency' : 'IDR'
                // });
                // console.log("TOTAL BAYAR: "+harga);
                var data = JSON.parse(hasil);
                
                if (hasil != 0) {
                    $('#gift-pilih').hide();
                    $('#gift-konfir').hide();
                    $('#gift-xendit').show();
                    frame = '<iframe style="height: 100%" src="'+ data['url'] +'" height="auto" width="100%" title="Iframe Example"></iframe>';
                    $('#frame-xendit-gift').html(frame);
                    setTimeout(function (){
                        $('#btn-tracking-gift').text('Selesai');
                    }, 5000);


                }

                window.dataLayer.push({
                    'event': 'gift_submit'
                });

                // $("#btn-pembayaran-gift").html('Selesai');

            }
            })
        return false;
    });

    function reloadGift() {
        document.querySelector('#box_ucapan').scrollIntoView({behavior: 'smooth'});
        loadUcapan()
        closeGiftModal()
    }


    // End Gift



// pindahkan ini nanti ke realtime-edit.js
function openEmbed(embedUrl) {
    $('#embed-info').empty();
    var embedCode = '<iframe src="' + embedUrl + '" width="100%" height="100%" frameborder="0" allowfullscreen></iframe>';
    $('#embed-info').html(embedCode);
    openEditModal('info')
}

function embedLink(embedUrl) {
    $('#embed-link').empty();
    var embedCode = '<iframe src="' + embedUrl + '" width="100%" height="100%" frameborder="0" allowfullscreen></iframe>';
    $('#embed-link').html(embedCode);
    openEditModal('embed');

    $('#embed-link iframe').on('load', function() {
        $('#loader').hide();
        $('#loader-container').hide();
    });

    $('#loader').show();
    $('#loader-container').show();
}

function saveLink() {
    var event = "Pernikahan Ali Sandi, S.P &amp; Ays, S.Pd";
    var month = '1';
    var date = '3';
    var th  = '2026';
    var link = 'https://calendar.google.com/calendar/u/0/r/eventedit?text='+event+'&dates='+th+month+date+'T080000/'+th+month+date+'T090000';
    window.open(link, '_blank');
}


// mouseflow
window._mfq = window._mfq || [];
window._mfq.push(["setVariable", "paket", "2"]);


// popup gambar
if (document.querySelector("#fh5co-gallery-list")) {
    $('#fh5co-gallery-list').magnificPopup({
        delegate: 'a.image-popup',
        type: 'image',
        mainClass: 'mfp-with-zoom mfp-img-mobile',
        tLoading: 'Loading image',
        gallery: {
            enabled: true,
            navigateByImgClick: true,
            preload: [0, 1]
        },
        zoom: {
            enabled: true,
            duration: 300,
            opener: function(element) {
                return element.find('.case-studies-summary');
            }
        },
        image: {
          markup: `<div class="mfp-figure">
              <div class="mfp-close"></div>
              <div style="position: relative; display: inline-block;">
                <img class="mfp-img"/>
                <a id="download-btn" href="#" target="_blank"
                  style="
                    position: absolute;
                    bottom: 0;
                    right: 0;
                    z-index: 9;
                    display: inline-block;
                    color: #fff;
                    background: #333;
                    padding: 10px;
                    text-decoration: none;
                    margin-bottom: 3px;
                  ">
                  <svg style="display: inline; color: white;" class="w-5 h-5 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 15v2a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-2m-8 1V4m0 12-4-4m4 4 4-4"/>
                  </svg>
                  Download
                </a>
              </div>
          </div>`,
          titleSrc: function(item) {
            setTimeout(function () {
              fetch(item.src, { mode: 'cors' })
                .then(res => res.blob())
                .then(blob => {
                  const url = URL.createObjectURL(blob);
                  const fileName = item.src.split('/').pop();
                  const a = document.getElementById('download-btn');
                  a.href = url;
                  a.setAttribute('download', fileName);
                })
                .catch(() => {
                  $('#download-btn').attr('href', item.src);
                });
            }, 10);
          }
        },
    });
}
if(document.querySelector("#galleryGrid")){
    $('#galleryGrid').magnificPopup({
		delegate: 'a',
		type: 'image',
		tLoading: 'Loading image',
		mainClass: 'mfp-img-mobile',
		gallery: {
			enabled: true,
			navigateByImgClick: true,
			preload: [0,1]
		},
    zoom: {
      enabled: true,
      duration: 300,
      opener: function(element) {
        return element.find('img');
      }
		},
    image: {
      markup: `<div class="mfp-figure">
              <div class="mfp-close"></div>
              <div style="position: relative; display: inline-block;">
                <img class="mfp-img"/>
                <a id="download-btn" href="#" target="_blank"
                  style="
                    position: absolute;
                    bottom: 0;
                    right: 0;
                    z-index: 9;
                    display: inline-block;
                    color: #fff;
                    background: #333;
                    padding: 10px;
                    text-decoration: none;
                    margin-bottom: 3px;
                  ">
                  <svg style="display: inline; color: white;" class="w-5 h-5 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 15v2a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-2m-8 1V4m0 12-4-4m4 4 4-4"/>
                  </svg>
                  Download
                </a>
              </div>
            </div>`,
      titleSrc: function(item) {
        setTimeout(function () {
          fetch(item.src, { mode: 'cors' })
            .then(res => res.blob())
            .then(blob => {
              const url = URL.createObjectURL(blob);
              const fileName = item.src.split('/').pop();
              const a = document.getElementById('download-btn');
              a.href = url;
              a.setAttribute('download', fileName);
            })
            .catch(() => {
              $('#download-btn').attr('href', item.src);
            });
        }, 10);
      }
    }
	});
}
if ("mediaSession" in navigator) {
    navigator.mediaSession.metadata = new MediaMetadata({
    title: " Pernikahan Ali Sandi, S.P &amp; Ays, S.Pd ",
    artist: "Undangan Online",
    artwork: [
        {
        src: "./img2/9.jpg",
        sizes: "512x512",
        type: "image/webp",
        },
    ],
    });
}

const scrollToBox2 =  () => {
            $('.mouse_scroll').click(function (e) {
                e.preventDefault();
                document.querySelector('.box-2').scrollIntoView({behavior: 'smooth'});
            });
        }


function getCookieValue(name) {
    const cookies = document.cookie.split('; ');
    for (let i = 0; i < cookies.length; i++) {
        const [key, value] = cookies[i].split('=');
        if (key === name) {
            return decodeURIComponent(value);
        }
    }
    return null;
}

if (getCookieValue('is-mobile') == 'yes') {
    localStorage.setItem('isMobile', true);
}

// CEK IS MOBILE APK
let searchP = new URLSearchParams(window.location.search)
let params1 = searchP.get('utm_campaign');
if (params1 == 'mobile-app') {
    // console.log('MASUK CEK UTM');
    localStorage.setItem('isMobile', true);
}
var cekMobile = localStorage.getItem('isMobile');



var jsonStyleCustomTema = null;

if(!jsonStyleCustomTema) { // temporary
  jsonStyleCustomTema = null;
}

// $('#c-link-id h1 span').css('margin-top', '500px');
// console.log(json.style);

function applyStylesFromJson(jsonData) {
  // Traverse top-level keys in JSON
  Object.keys(jsonData).forEach((selectorKey) => {
    const selector = `${selectorKey}`; // Convert key to ID selector (e.g., "cLink" -> "#cLink")
    const styles = jsonData[selectorKey];

    // Apply styles to the target selector
    // console.log(styles);

    applyStylesToSelector(styles, selector);
  });
}

function applyStylesToSelector(styles, selector) {
    var elstyle = '';
    selector = selector.replace(/@/g, ' ').replace(/!/g, '.');
    Object.keys(styles).forEach((key) => {
        if (styles[key] == '' || styles[key] == 'default') {
            // jika style kosong, maka jangan di proses
            return;
        }
        if (typeof styles[key] === "object") {
            // Recursive call for nested objects
            applyStylesToSelector(styles[key], selector);
        } else {
            // Apply style if key-value pair represents CSS
            const cssKey = key.replace(/_/g, '-'); // Convert keys like 'margin_top' to 'margin-top'
            //   $(selector).css(cssKey, styles[key]);
            //   console.log(`${selector}.css(${cssKey},${styles[key]})`);
            if (!isNaN(parseFloat(styles[key]))) {
              if (!styles[key].toString().endsWith('px')) { // jika tidak ada px

                if(selector.includes('img') && key == 'width'){ // jika itu image dan width
                  styles[key] = styles[key] + '%';
                } else {
                  styles[key] = styles[key] + 'px';
                }
              }
            }

            elstyle = elstyle+`${cssKey}:${styles[key]} !important; `;
        }
    });
    var currentStyle = $(selector).attr('style');
    if (typeof currentStyle === 'undefined') {
        currentStyle = '';
    }

    if (selector.includes('.')) {
        // jika selector berupa class, maka hanya berimpact pada 1 class saja
        $(selector).eq(0).attr('style', currentStyle + ';' + elstyle);
    } else {
        $(selector).attr('style', currentStyle + ';' + elstyle);
    }


            }

applyStylesFromJson(jsonStyleCustomTema.style);

</script>

        
        <script type="text/javascript">
            $(document).ready(function () {

                $('#tombol_kirim_2').removeClass("bg-primary");
                $("#tombol_kirim_2").addClass("btn btn-primary");
                $("#link-foot").addClass("btn btn-primary");
                $("#link-foot").removeAttr("style");

                document.addEventListener('DOMContentLoaded', function () {
                    var splide = new Splide('#image-carousel', {
                        type: "loop",
                        height: '12rem',
                        cover: true,
                        gap: "1rem",
                        perPage: 3,
                        perMove: 1,
                        rewind : true,
                        autoplay: true,
                        pagination: false,
                        arrows: false,
                        speed: 2000,
                    });
                    splide.mount();
                    setTimeout(function() {
                        AOS.refresh();
                    }, 500);
                });
            });


            // document.addEventListener('DOMContentLoaded', function () {
            //     var splide = new Splide('.splide', {
            //         type: 'fade',
            //         rewind: true,
            //         autoplay: true,
            //         pagination: false,
            //         arrows: false,
            //         // easing: 'ease 2s',
            //         speed: 2000
            //     });
            //     splide.mount();
            // });
        </script>
    </div>
</body>

</html>
